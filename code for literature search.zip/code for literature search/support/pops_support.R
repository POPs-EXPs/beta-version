
paper_data_all<-function(url){
  
  #Web information
  webpage<-read_html(url) 
  
  #judgement
  judgement<-webpage%>%html_nodes(".return-to-search")%>%html_text()
  
  if(length(judgement)>0){
    
    #get the title
    title0<-webpage%>%html_nodes(".heading-title")%>%html_text()
    title0<-gsub("\n","",title0)
    title0<-gsub("^\\s+|\\s+$", "",title0) #remove spaces
    title<-title0[1]
    
    #get the author
    author0<-webpage%>%html_nodes(".full-name")%>%html_text()
    author<-author0[1]
    
    #get the PMID
    PMID0<-webpage%>%html_nodes(".current-id")%>%html_text()
    PMID<-PMID0[1]
    
    #get the periodical
    periodical<-webpage%>%html_nodes("#full-view-journal-trigger")%>%html_text()
    periodical<-gsub("\n","",periodical)
    periodical<-gsub("^\\s+|\\s+$", "",periodical)
    
    #get the date
    date0<-webpage%>%html_nodes(".cit")%>%html_text()
    date<-date0[1]
    year<-str_sub(date, start = 1L, end = 5L)
    
    #get the DOI
    # DOI0<-webpage%>%html_nodes(".id-link")%>%html_text()
    # DOI0<-gsub("\n","",DOI0)
    # DOI0<-gsub("^\\s+|\\s+$", "",DOI0) #remove spaces
    # DOI<-DOI0[1]
    
    #get the link of paper
    paperlink<-paste0("https://pubmed.ncbi.nlm.nih.gov/",PMID[1],"/")
    
    
    
    #get the abstract
   # abstract<-webpage%>%html_nodes("#abstract p")%>%html_text()
  #  abstract<-gsub("\n","",abstract)
   # abstract<-gsub("^\\s+|\\s+$", "",abstract) 
    
    data<-data.frame("title"=title, "author"=author, "PMID"=PMID, "date"=date, "year"=year,"periodical"=periodical, "link"=paperlink)
    
  }else{
    
    
    #get the title
    title<-webpage%>%html_nodes(".docsum-title")%>%html_text()
    title<-gsub("\n","",title)
    title<-gsub("^\\s+|\\s+$", "",title) #remove spaces
    
    #get the author
    author<-webpage%>%html_nodes(".full-authors")%>%html_text()
    
    #get the PMID
    PMID<-webpage%>%html_nodes(".full-citation .docsum-pmid")%>%html_text()
    
    #get the periodical and date
    periodical_date<-webpage%>%html_nodes(".full-journal-citation")%>%html_text()
    periodical<-sapply(str_split(periodical_date,"\\."),'[',1)
    date<-sapply(str_split(periodical_date,"\\."),'[',2)
    year<-str_sub(date, start = 1L, end = 5L)
    
    #get the link of paper
    paperlink<-vector()
    for (i in 1:length(PMID)){
      paperlink[i]<-paste0("https://pubmed.ncbi.nlm.nih.gov/",PMID[i],"/")
    }
    
    #get the abstract
   # abstract<-PMID#keyword<-vector()
    # DOI<-PMID
    
   #  for (i in 1:length(PMID)) {
     # abc<-paperlink[i]%>%read_html()%>%html_nodes("#abstract p")%>%html_text()
    #  if(length(abc)!=0){abstract[i]<-abc}else{abstract[i]<-'No abstract'}
     # abstract[i]<-gsub("\n","",abstract[i])
    #  abstract[i]<-gsub("^\\s+|\\s+$", "",abstract[i]) 
     # efg<-paperlink[i]%>%read_html()%>%html_nodes(".id-link")%>%html_text()
      # if(length(efg)!=0){DOI[i]<-abc}else{DOI[i]<-'No DOI'}
      # DOI[i]<-gsub("\n","",DOI[i])
      # DOI[i]<-gsub("^\\s+|\\s+$", "",DOI[i]) #remove spaces
      
      #data summarization
      data<-data.frame("title"=title, "author"=author, "PMID"=PMID, "date"=date, "year"=year, "periodical"=periodical, "link"=paperlink)
      
   # }
  }
  return(data)
}
