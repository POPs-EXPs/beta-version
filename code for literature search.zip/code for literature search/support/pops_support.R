
paper_data_all<-function(url){
  
  #Web information
  webpage<-read_html(url) 
  
  #judgement
  judgement<-webpage%>%html_nodes(".return-to-search")%>%html_text()
  
  if(length(judgement)>0){
    
    #get the title
    title0<-webpage%>%html_nodes(".heading-title")%>%html_text()
    title0<-gsub("\n","",title0)
    title0<-gsub("^\\s+|\\s+$", "",title0) #remove spaces
    title<-title0[1]
    
    #get the author
    author0<-webpage%>%html_nodes(".full-name")%>%html_text()
    author<-author0[1]
    
    #get the PMID
    PMID0<-webpage%>%html_nodes(".current-id")%>%html_text()
    PMID<-PMID0[1]
    
    #get the periodical
    periodical<-webpage%>%html_nodes("#full-view-journal-trigger")%>%html_text()
    periodical<-gsub("\n","",periodical)
    periodical<-gsub("^\\s+|\\s+$", "",periodical)
    
    #get the date
    date0<-webpage%>%html_nodes(".cit")%>%html_text()
    date<-date0[1]
    year<-str_sub(date, start = 1L, end = 5L)
    
    #get the DOI
     DOI0<-webpage%>%html_nodes(".id-link")%>%html_text()
     DOI0<-gsub("\n","",DOI0)
     DOI0<-gsub("^\\s+|\\s+$", "",DOI0) #remove spaces
     DOI<-DOI0[1]
     
     if (grepl('PMC',DOI0[1]))
     {
       DOI<-DOI0[2]
     }
    
    #get the link of paper
    paperlink<-paste0("https://pubmed.ncbi.nlm.nih.gov/",PMID[1],"/")
    
    
    data<-data.frame("title"=title, "author"=author, "PMID"=PMID, doi=DOI, "date"=date, "year"=year,"periodical"=periodical, "link"=paperlink)
    
  }else{
    
    
    #get the title
    title<-webpage%>%html_nodes(".docsum-title")%>%html_text()
    title<-gsub("\n","",title)
    title<-gsub("^\\s+|\\s+$", "",title) #remove spaces
    
    #get the author
    author<-webpage%>%html_nodes(".full-authors")%>%html_text()
    
    #get the PMID
    PMID<-webpage%>%html_nodes(".full-citation .docsum-pmid")%>%html_text()
    
    #get the periodical and date
    periodical_date<-webpage%>%html_nodes(".full-journal-citation")%>%html_text()
    periodical<-sapply(str_split(periodical_date,"\\."),'[',1)
    date<-sapply(str_split(periodical_date,"\\."),'[',2)
    year<-str_sub(date, start = 1L, end = 5L)
    
    #get the link of paper
    paperlink<-vector()
    for (i in 1:length(PMID)){
      paperlink[i]<-paste0("https://pubmed.ncbi.nlm.nih.gov/",PMID[i],"/")
    }
    
    startsu<-str_locate(periodical_date,"doi:")
    endsu<-str_locate(periodical_date,"Epub")

     DOI<-PMID
   
     for (i in 1:length(PMID)) {
   
       if (!is.na(endsu[i,1]))
       {
       DOI[i]<-str_sub(periodical_date[i],start=startsu[[i,2]]+2,end=endsu[i,1]-3) } else 
       {
         DOI[i]<-str_sub(periodical_date[i],start=startsu[[i,2]]+2,end=-2)
       }
     }
      
      #data summarization
      data<-data.frame("title"=title, "author"=author, "PMID"=PMID, doi=DOI,"date"=date, "year"=year, "periodical"=periodical, "link"=paperlink)
      
  
  }
  return(data)
}
