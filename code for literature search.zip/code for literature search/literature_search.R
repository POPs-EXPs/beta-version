
list.of.packages<-c("openxlsx",'rvest',"stringr","readr")

new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
for(name in list.of.packages){
  #
  require(name,character.only = TRUE)
}
rm(list=ls())
pathway<-getwd()
outputpath<-paste0(pathway,'/csvoutput/')
name_list<-read_csv(paste0(pathway,"/name_list.txt"))
name_list_file<-read_csv(paste0(pathway,"/name_list_file.txt"))

media_list<-read_csv(paste0(pathway,"/media_list.txt")) # name for environmental media
media_list_file<-read_csv(paste0(pathway,"/media_list_file.txt")) # file namefor environmental media
source(paste0(pathway,'/support/pops_support.R')) # support function
for (name_list_loop in 1:length(name_list$name))
{
  for (media_list_loop in 1:length(media_list$name))
  {
keyword<-paste0(name_list$name[name_list_loop],"+and+",media_list$name[media_list_loop])
keyword1<-paste0(name_list_file$name[name_list_loop],"_",media_list_file$name[media_list_loop])
path_tmp1<-paste0(pathway,'/data_raw/',name_list_file$name[name_list_loop])
if (!file.exists(path_tmp1))
{
  dir.create(path_tmp1) 
}

keyword<-paste0(name_list$name[name_list_loop],"+and+",media_list$name[media_list_loop])
keyword1<-paste0(name_list_file$name[name_list_loop],"_",media_list_file$name[media_list_loop])
path_tmp1<-paste0(pathway,'/data_raw/',name_list_file$name[name_list_loop])
if (!file.exists(path_tmp1))
{
  dir.create(path_tmp1) 
}
result<-NULL
for(i in 1:10000){
result_page<-NULL
url_temp<-paste0('https://pubmed.ncbi.nlm.nih.gov/?term=',keyword,"+and+China&page=",i) #get the  url
result_page<-try(paper_data_all(url_temp),silent=TRUE)
if (class(result_page)!='try-error' && nrow(result_page)<10 && nrow(result_page)>0 ) 
{

  result<-rbind(result,result_page) 
  break
  
} else if (class(result_page)!='try-error' && nrow(result_page)==10 )
  
{
  result<-rbind(result,result_page)
  } else 
{
break
}


}
if (!is.null(result))
{
  if (file.exists(paste0(path_tmp1,"/",keyword1,'.xlsx')))
  {
    file.remove(paste0(path_tmp1,"/",keyword1,'.xlsx'))
  }
write.xlsx(result,paste0(path_tmp1,"/",keyword1,'.xlsx'))

}
}
}
