#system("find /homes/cctdb/shiny/pops/temp/ -mtime +1 -name '*.*' -exec rm -rf {} \\;")
pathset<-getwd() # to change current directory as the working directory

list.of.packages<-c("shiny","shinydashboard","DT","shinyalert","readxl","readr","openxlsx","shinyWidgets",
                    "ggplot2","shinyBS","fitdistrplus","stringr","mapdata","maptools","ggplot2","plyr","mapproj")

new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
for(name in list.of.packages){
  #
  require(name,character.only = TRUE)
}

seedrnd<-as.character(sample(1:1000000,size=1))

ind_code_path<<-paste0(pathset,"/temp/",seedrnd,"_")
file.copy(from='./work/literature/download_temp.xlsx',
          to=paste0(ind_code_path,'lit_summary.xlsx'),overwrite = TRUE)

file.copy(from='./work/literature/download_temp.xlsx',
          to=paste0(ind_code_path,'exposure_database.xlsx'),overwrite = TRUE)

file.copy(from='./work/literature/download_temp.xlsx',
          to=paste0(ind_code_path,'data_analysis.xlsx'),overwrite = TRUE)
file.copy(from='./work/literature/download_temp.xlsx',
          to=paste0(ind_code_path,'recent.xlsx'),overwrite = TRUE)

downloaddir<-paste0("./temp/",seedrnd,'/download/')
downloaddirplus<-paste0('./temp/',seedrnd,'/download.zip')
dir.create(paste0("./temp/",seedrnd))
dir.create(downloaddir)

dir.create(paste0(downloaddir,'literature/')) 
dir.create(paste0(downloaddir,'data/')) 

# file.copy(from='./work/literature/all.xlsx',
#           to=paste0(downloaddir,'literature/literature_information.xlsx'),overwrite = TRUE)

# file.copy(from='./work/database/', to=paste0(downloaddir,'data/'),
#           overwrite = TRUE,recursive=TRUE)
# 
# file.copy(from='./work/analysis/PoPs/', to=paste0(downloaddir,'data/'),
#           overwrite = TRUE,recursive=TRUE)

# file.copy(from='./work/recent/recent.xlsx',
#           to=paste0(downloaddir,'literature/recent_literature.xlsx'),overwrite = TRUE)
# 
# file.copy(from='./work/quality/data_quality.xlsx',
#           to=paste0(downloaddir,'literature/data_quality.xlsx'),overwrite = TRUE)

pathway_list<-c("air","dust","soil","sediment","water","food","blood","breast milk","biological","others")
pathway_hhra<-c("air","soil","water","food")
pathway_hhra_unit<-c("ng/m3","ng/kg","ng/L","ng/kg")
pathway_list_analysis<-c("air","dust","soil","sediment","water","food","blood","breast milk")

air_unit_list<-c('ng/m3')
dust_unit_list<-c('ng/kg',"ng/kg dw")
soil_unit_list<-c('ng/kg',"ng/kg dw")
sediment_unit_list<-c('ng/kg',"ng/kg dw")
food_unit_list<-c('ng/kg',"ng/kg ww","ng/kg dw")
water_unit_list<-c('ng/L')
blood_unit_list<-c('ng/kg',"ng/kg lw","ng/L")
breast_unit_list<-c('ng/kg',"ng/kg lw","ng/L")

group_list<-c('OCPs',"Dioxins and PCBs","BFRs","PFASs","Other POPs")
group_list_recent<-c('OCPs',"Dioxins and PCBs","BFRs","PFASs","Other POPs","Unclassified")
OCP_list<-c('Aldrin', 'Chlordane', 'Chlordecone', 'DDT', 'Dicofol', 'Dieldrin','Endrin',
             'Endosulfan', 'Heptachlor','Hexachlorobenzene', 'Hexachlorocyclohexane', 
            'Mirex', 'Pentachlorobenzene', 'Pentachlorophenol','Toxaphene')

PCDD_list<-c('PCDD&Fs',"PBDD&Fs","PCBs")
PFAS_list<-c('PFOA',"PFOS")
BFR_list<-c("Hexabromocyclododecane","Hexabromobiphenyl",'PBDEs')
Others_list<-c( "Hexachlorobutadiene","Polychlorinated naphthalenes","SCCPs")
# chemical_list<-c('Aldrin',"Chlordane","Chlordecone","SCCPs","DDT",'Dicofol',
#                  "Dieldrin",'PCDDs',"PCDFs","Endrin","Endosulfan","HBB","Hexabromocyclododecane","HCB",
#                  "HCBD","HCH","Heptachlor","Mirex","PCP","PCNs","PCBs",
#                  "Pentachlorobenzene","PFOA","Toxaphene","PFOS")

download_literature<-c('Literature list for exposure database',
                       'Recent literature (data has not been extracted)',
                       'QA/QC and sampling information of each literature')
chemical_list<-c(OCP_list,PCDD_list,PFAS_list,BFR_list,Others_list)
chemical_list_recent<-c(OCP_list,PCDD_list,PFAS_list,BFR_list,Others_list,'Unclassified')

download_supporting<-c('Manual', 'Code',"Abbreviations")
download_data_list<-c("Raw records used for database","Standardized data used for analysis and human health risk assessment")

quality_list<-c('high',"medium",'poor')

main_code_path<<-paste0(pathset,"/work/")
#supp_code_path<-paste0(pathset,'/work/code/pops_project_support.R')
#source(supp_code_path,encoding = "utf-8")

#---------#Introduction--------
Module_introduction_Ui<-function(id){
  ns <- NS(id)
 # fluidPage(theme = "custom.css")
  tabItem(tabName = "introduction",
          fluidPage(
           fluidRow(uiOutput(ns("introduction"))
                #    br(),
          #   fluidRow(
           
           #downloadBttn(ns('manual'),label='Data, Code and Manual',size='sm',color="success",style='pill')
            # )
            )
          )
          
  )
}

Module_introduction_Server <- function(input, output, session) {
  
  output$introduction<-renderUI({fluidPage(h2("PoPs_EXPs Project",align = "center",style = "font-family: 'Baskerville'; font-size: 380%; font-weight: 300"),
                                           h5("PoPs_EXPs project aims to establish an online database on the exposure to persistent organic pollutants (PoPs) in China. 
Seven tools were included in our database:",style ="font-family: 'Helvetica Neue',Helvetica;font-weight: 200;
                                              line-height: 2.1; font-size: 150%; text-indent:2em"),
                                           h5("1) literature list: to summarize the literature associated with POPs exposure in China. Current version included the literature that published by the end of May, 2020; ",style ="font-family: 'Helvetica Neue',Helvetica;font-weight: 200;
                                              line-height: 2.1; font-size: 150%; text-indent:2em"),
                                           h5("2) exposure database: to illustrate the extracted exposure data from the publications in literature list; ",style ="font-family: 'Helvetica Neue',Helvetica;font-weight: 200;
                                              line-height: 2.1; font-size: 150%; text-indent:2em"),
                                           h5("3) data analysis: to perform the spatiotemporal trend analysis of PoPs exposure in China;",style ="font-family: 'Helvetica Neue',Helvetica;font-weight: 200;
                                              line-height: 2.1; font-size: 150%; text-indent:2em"),
                                           h5("4) human health risk assessment: to conduct simple human risk assessment for PoPs;",style ="font-family: 'Helvetica Neue',Helvetica;font-weight: 200;
                                              line-height: 2.1; font-size: 150%; text-indent:2em"),
                                          
                                           h5("5) data quality: to assess the data quality by evaluating quality assurance/quality control and other information of published literature; ",style ="font-family: 'Helvetica Neue',Helvetica;font-weight: 200;
                                              line-height: 2.1; font-size: 150%; text-indent:2em"),
                                           h5("6) recent literature: to retrieve recent published reports with respect to PoPs exposure in China, while the data from these reports have not yet been extracted and incorporated in the exposure database;",style ="font-family: 'Helvetica Neue',Helvetica;font-weight: 200;
                                              line-height: 2.1; font-size: 150%; text-indent:2em"),
                                           h5("7) data download: to offer custom query downloads. ",style ="font-family: 'Helvetica Neue',Helvetica;font-weight: 200;
                                              line-height: 2.1; font-size: 150%; text-indent:2em"),
                                           br(),
                                           # h5("Update date:  12-August-2020",style = "font-family: 'Helvetica Neue',Helvetica; font-weight: 200;
                                           #    line-height: 2.1; font-size: 150%"),    
                                         
                                        
                                         #  h5("Contact: dongzm@buaa.edu.cn. More detailed information pls refer to", a("POPs-EXPs",href="https://github.com/POPs-EXPs/beta-version",color='red'),"on Github",style = "font-family: 'Helvetica Neue',Helvetica; font-weight: 200;
                                          #    line-height: 2.1; font-size: 130%")
                                           h5("Contact information: dongzm@buaa.edu.cn; zhaoxiaoli_zxl@126.com; fanwh@buaa.edu.cn",style = "font-family: 'Helvetica Neue',Helvetica; font-weight: 200;
                                             line-height: 2.1; font-size: 130%; text-indent:2em")   
                                           )})
  
  # output$manual<-downloadHandler(filename = function(){
  #   paste("Data, Code and manual", ".zip", sep="")
  # },
  # content=function(con)
  # {file.copy(paste0(pathset,"/work/code/supporting information.zip"),con)
  # })
   }
#-------liteature------------

#Ui/Server for exposure
Module_lit_Ui<-function(id){
  ns <- NS(id)
  tabItem(tabName = "lit", 
          fluidPage(
            fluidRow(
              box(title = "Step 1. Chemical Selection", width =4, solidHeader = TRUE,  
                  status = "primary",collapsible=TRUE, collapsed=FALSE,
               selectInput(ns('groups'),"Group",choices=group_list,selected='OCPs'),
                checkboxGroupInput(ns('chemicals'), 'Chemical',choices=OCP_list, selected=OCP_list,
                                  inline=TRUE)
                  
              ),
              
              box(title = "Step 2. Pathway Identification", width = 4, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  checkboxGroupInput(ns('pathway'), label=NULL, choices=pathway_list, selected=pathway_list,
                                     inline=TRUE)

              ),
              
              box(title = "Step 3. Literature Searach", width = 3, solidHeader = TRUE, collapsible=TRUE, collapsed=FALSE,
                  status = "primary",
                  actionBttn(ns("data_shown"), label='GO!',color = "primary",style = "gradient",size='lg'),
             #    actionButton(ns("data_shown"), 'GO!',style="color: #FFFFFF; background-color: #36648B; border-color: #36648B"),
                  br(),
                  br(),
                 
             downloadBttn(ns('data_shown_download'),label='Data Download',size='sm',color="success",style='pill')
          #    downloadButton(ns('data_shown_download'),
           #                       "Download",style="color: #FFFFFF; background-color: #339900; border-color: #339900")
               )
             

            ),
            
             fluidRow(uiOutput(ns("title_pollutant"))),
             fluidRow(DT::dataTableOutput(ns("liteature_data"))),
            br(),
          fluidRow(uiOutput(ns("year_title"))),
          imageOutput((ns("year"))),
          fluidRow(uiOutput(ns("journal_title"))),
            imageOutput((ns("journal")))
            )
          )
}

Module_lit_Server<- function(input, output, session){
  
  observeEvent(input$groups,
               {
                 
                 if (input$groups=='OCPs')
                 {
                   updateCheckboxGroupInput(session,'chemicals', 'Chemical',choices=OCP_list, 
                                            selected=OCP_list, inline=TRUE)
                 
                   } else if (input$groups=='Dioxins and PCBs')
                 {
                   updateCheckboxGroupInput(session,'chemicals','Chemical',choices=PCDD_list, selected=PCDD_list,
                                           inline=TRUE)
                 } else if (input$groups=='BFRs')
                 {
                   updateCheckboxGroupInput(session,'chemicals','Chemical',choices=BFR_list, selected=BFR_list,
                                           inline=TRUE)
                 } else if (input$groups=='PFASs')
                 {
                   updateCheckboxGroupInput(session,'chemicals','Chemical',choices=PFAS_list, selected=PFAS_list,
                                            inline=TRUE)
                 } else if (input$groups=='Other POPs')
                 {
                   updateCheckboxGroupInput(session,'chemicals','Chemical',choices=Others_list, selected=Others_list,
                                           inline=TRUE)
                 }
               }
)

 output$data_shown_download<-downloadHandler(filename = function(){
    paste("lit_summary",gsub(":","-",Sys.time()), ".xlsx", sep="")
  },
  content=function(con)
  {file.copy(paste0(ind_code_path,'lit_summary.xlsx'),con)
  })

  observeEvent(input$data_shown,
               {
                 output$title_pollutant<-renderUI({mainPanel(h3("Available liteature on exposure data for selected PoPs ")  )})
                 data_all<-read.xlsx('./work/literature/all.xlsx')
                 data_show<-subset(data_all, Chemical %in% input$chemicals & Pathway %in% input$pathway)
                 data_show1<-subset(data_all,Chemical %in% input$chemicals & Article_Type=='Review' )
                 data_show<-rbind(data_show,data_show1)
               
                 
                 
                 filetemp=paste0(ind_code_path,'lit_summary.xlsx')
                 write.xlsx(data_show,filetemp)
                 output$liteature_data<-renderDT(
                   datatable(
                     data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                     editable = FALSE))
                 
                 if (nrow(data_show)>0)
                 {
                   data_temp<-data_show[,c(4:ncol(data_show))]
                   result<-data_temp[!duplicated(data_temp$Article_ID),]
                  # result<-unique(data_temp$publication)
                 
                 output$year_title<-renderUI({mainPanel(
                   h3("The number of publications in each year")
                 )})
                 output$journal_title<-renderUI({mainPanel(
                   h3("The statistical distribution of journals")
                 )})
                 
                 
                 year_list_all<-as.double(as.character(result$Year))
                 year_list<-sort(unique(as.double(as.character(result$Year))))
                
                 year_number<-rep(0,length(year_list))
                 
                 for (i in 1:length(year_list))
                 {
                   year_number[i]<-length(which(year_list_all==year_list[i]))
                 }
                 
                 journal_list<-((unique(result$Journal)))
                 journal_number<-rep(0,length(journal_list))
                 for (i in 1:length(journal_list))
                 {
                   journal_number[i]<-length(which(result$Journal==journal_list[i]))
                 }
                 outfile <- paste0(ind_code_path,'_publication.png')
                 if (file.exists(paste0(ind_code_path,'_publication.png')))
                 {
                   file.remove(paste0(ind_code_path,'_publication.png'))
                 }
                 png(outfile, width =640, height = 360)
                
                 gp1<-plot(year_list,year_number,type='b',
                           xlab = "Year", ylab="Number")
                 
              
                 
                 dev.off()
                 output$year<-renderImage({
                   filename <- normalizePath(file.path(paste0(ind_code_path,'_publication.png'))) #download, need to refine
                   list(src = filename,width=640,height=360)
                 },deleteFile = FALSE
                 
                 )
                 
                 journal_label=data.frame(number=journal_number,name=journal_list)
                 order_tmp<-order(journal_label$number,decreasing=TRUE)
                 journal_label<-journal_label[order_tmp,]
                 n=5
                 if (nrow(journal_label)>n+1)
                 {
                   journal_label1<-journal_label[1:(n+1),]
                   journal_label2<-journal_label[-c(1:(n)),]
                   other_num<-sum(journal_label2$number,na.rm=TRUE) 
                   journal_label1[n+1,1]<-other_num
                   journal_label1$name<-as.character(journal_label1$name)
                   journal_label1[n+1,2]<-'Others'
                 } else
                 {
                   journal_label1<-journal_label
                   
                   journal_label1$name<-as.character(journal_label1$name)
                   
                 }
                 
                 for ( i in 1:nrow(journal_label1))
                 {
                   journal_label1$label[i]<-paste0(journal_label1$name[i],"(",journal_label1$number[i],")")
                 }
                 
                 outfile <- paste0(ind_code_path,'_journal.png')
                 if (file.exists(paste0(ind_code_path,'_journal.png')))
                 {
                   file.remove(paste0(ind_code_path,'_journal.png'))
                 }
                 png(outfile, width =640, height = 360)
                 gp1<-pie(journal_label1$number,label=journal_label1$label,
                          main="Journals",col= terrain.colors (length(journal_label1$number)))
                 
                 dev.off()
                 output$journal<-renderImage({
                   filename <- normalizePath(file.path(paste0(ind_code_path,'_journal.png'))) #download, need to refine
                   list(src = filename,width=640,height=360)
                 },deleteFile = FALSE
                 
                 )
                 }
                 
               } 
              
  )

}

#-------PoPs database-------------

Module_database_Ui<-function(id){
  ns <- NS(id)
  tabItem(tabName = "database", 
          fluidPage(
            fluidRow(
              box(title = "Step 1. Chemical Selection", width =4, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  selectInput(ns('groups'),"Group",choices=group_list,selected='OCPs'),
                  selectInput(ns('chemicals'), 'Chemical',choices=OCP_list, selected=OCP_list[1]
                                     )
                  
              ),
              
              box(title = "Step 2. Pathway Identification", width = 4, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  checkboxGroupInput(ns('pathway'), label=NULL, choices=pathway_list, selected=pathway_list,
                                     inline=TRUE),
                  checkboxGroupInput(ns('data_quality'), label='Data quality filter',choices=quality_list, selected=quality_list,
                                     inline=TRUE
                  )
                  
              ),
              
              box(title = "Step 3. Data Display", width = 3, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                #  actionButton(ns("data_shown"), 'Data Shown',
                 #              width=120,style="color: #FFFFFF; background-color: #339900; border-color: #339900"),
                actionBttn(ns("data_shown"), label='GO!',color = "primary",style = "gradient",size='lg'),  
                
                br(),
                  br(),
                downloadBttn(ns('data_shown_download'),label='Data Download',size='sm',color="success",style='pill')
                 # downloadButton(ns('data_shown_download'),
                  #               "Download",style="color: #FFFFFF; background-color: #339900; border-color: #339900")
              )
              
              
            ),
            
           fluidRow(uiOutput(ns("title_pollutant"))),
            fluidRow(DT::dataTableOutput(ns("liteature_data")))
            
          )
  )
}

Module_database_Server<-function(input, output, session) {

  
  observeEvent(input$groups,
               {
                 
                 if (input$groups=='OCPs')
                 {
                   updateSelectInput(session,'chemicals', 'Chemical',choices=OCP_list, 
                                            selected=OCP_list[1])
                   
                 } else if (input$groups=='Dioxins and PCBs')
                 {
                   updateSelectInput(session,'chemicals','Chemical',choices=PCDD_list, selected=PCDD_list[1])
                 } else if (input$groups=='BFRs')
                 {
                   updateSelectInput(session,'chemicals','Chemical',choices=BFR_list, selected=BFR_list[1])
                 } else if (input$groups=='PFASs')
                 {
                   updateSelectInput(session,'chemicals','Chemical',choices=PFAS_list, selected=PFAS_list[1])
                 } else if (input$groups=='Other POPs')
                 {
                   updateSelectInput(session,'chemicals','Chemical',choices=Others_list, selected=Others_list[1])
                 }
               }
  )
  
  output$data_shown_download<-downloadHandler(filename = function(){
    paste("exposure_database",gsub(":","-",Sys.time()), ".xlsx", sep="")
  },
  content=function(con)
  {file.copy(paste0(ind_code_path,'exposure_database.xlsx'),con)
  })
  
  observeEvent(input$data_shown,
               {
                 output$title_pollutant<-renderUI({mainPanel(h3("Exposure data for selected PoPs")  )})
           file_temp_name<-paste0('./work/database/',input$chemicals,'.xlsx')
           if (!file.exists(file_temp_name))
           {
             
             showModal(modalDialog(
               title = "Important message",
               "No available data",
               easyClose = TRUE))
           } else
           {
                 data_all<-read.xlsx(file_temp_name)
                 data_show<-subset(data_all, Pathway %in% input$pathway & Data_Quality %in% input$data_quality)
                 # data_show<-data_all
                 filetemp=paste0(ind_code_path,'exposure_database.xlsx')
                 write.xlsx(data_show,filetemp)
                 output$liteature_data<-renderDT(
                   datatable(
                     data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                     editable = FALSE)  %>%   formatSignif(columns = c(14:19), digits = 3))
                 
               } 
               
               }
  )
  
}

#------------temporal and spatial trend------------
Module_analysis_Ui <- function(id){
  ns <- NS(id)
  tabItem(tabName = "analysis",
          fluidPage(
            fluidRow(
              box(title = "Step 1. Data Selection", width =3, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  selectInput(ns('groups'),"Group",choices=group_list,selected='OCPs'),
                  selectInput(ns('chemicals'), 'Chemical',choices=OCP_list, selected=OCP_list[1]
                  ),
                  selectInput(ns('pathway'), label="Pathway", choices=pathway_list_analysis, selected=pathway_list_analysis[1]),
              #    actionBttn(ns("data_shown"), label='Data Display',color = "primary",style = "gradient",size='sm'),  
                  # actionButton(ns("data_shown"), label="Data Refresh (No)",
                  #              style="color: #000000; background-color: #4F94CD; border-color: #4F94CD"),
                  #              
              actionBttn(ns("data_shown"), label='Data Selection?',color = "primary",style = "gradient",size='md'),
                  br(),
                  br(),
                  
                  downloadBttn(ns('data_shown_download'),label='Data Download',size='sm',color="success",style='pill')
                 
                  
                
              ),
              
              box(title = "Step 2. Data Filter", width = 3, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  
                
                  selectInput(ns('chem_filter'), label='Congener filter',choices=c('all'), selected='all'),
                  selectInput(ns('unit'), label='Unit filter',choices=c('ng/m3',"ng/kg","ng/L"), selected='ng/kg'),
                  # actionButton(ns("filter"), label="Data Filt (No)",
                  #              style="color: #000000; background-color: #4F94CD; border-color: #4F94CD")
                  
                  checkboxGroupInput(ns('data_quality'), label='Data quality filter',choices=quality_list, selected=quality_list,
                                     inline=TRUE
                  ),
                  actionBttn(ns("filter"), label='Data Filter(Not done)',color = "primary",style = "gradient",size='md')
                   ),
              
              box(title = "Step 3. Temporal Trend", width = 3, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  sliderInput(ns("sample_year_temp"),label="Period",min=1980, max=2025, value=c(2000,2020)),
                  
                  checkboxGroupInput(ns("location_temp"), label="Province",choices=c('National'), selected=c('National')),
                 
                  
                  actionBttn(ns("temporal"), label='Temporal Analysis',color = "primary",style = "jelly",size='md')
                #   actionButton(ns("temporal"), label="Temporal Analysis",
                 #              width=130,style="color: #FFFFFF; background-color: #339900; border-color: #339900")
               
                  

              ),
              
              
              box(title = "Step 4. Spatial Trend", width = 3, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  sliderInput(ns("sample_year_spat"),label="Period",min=1980, max=2025, value=c(2000,2020)),
                  
                  checkboxGroupInput(ns("location_spat"), label="Province",choices=c('National'), selected=c('National')),
                  
                  
                  actionBttn(ns("spatial"), label='Spatial Analysis',color = "primary",style = "jelly",size='md')
                 
                  
              )
              
            ),
            fluidRow(
              splitLayout(cellWidths = c("50%", "50%"),
                          plotOutput(ns("plot2")),
                          plotOutput(ns("plot3")))
            ),
           
            fluidRow(uiOutput(ns("title_pollutant"))),

            
            fluidRow(DT::dataTableOutput(ns("liteature_data")))
            
          
            
          )    
  )
}

Module_analysis_Server <- function(input, output, session){

 
  
  
  observeEvent(input$groups,
               {
                 updateActionButton(session,inputId="data_shown",label="Data Selection (Done)")
                 updateActionButton(session,inputId="filter",label="Data Filter (Done)")
                 
                 if (input$groups=='OCPs')
                 {
                   updateSelectInput(session,'chemicals', 'Chemical',choices=OCP_list, 
                                     selected=OCP_list[1])
                   
                 } else if (input$groups=='Dioxins and PCBs')
                 {
                   updateSelectInput(session,'chemicals','Chemical',choices=PCDD_list, selected=PCDD_list[1])
                 } else if (input$groups=='BFRs')
                 {
                   updateSelectInput(session,'chemicals','Chemical',choices=BFR_list, selected=BFR_list[1])
                 } else if (input$groups=='PFASs')
                 {
                   updateSelectInput(session,'chemicals','Chemical',choices=PFAS_list, selected=PFAS_list[1])
                 } else if (input$groups=='Other POPs')
                 {
                   updateSelectInput(session,'chemicals','Chemical',choices=Others_list, selected=Others_list[1])
                 }
               }
  )
  
  output$data_shown_download<-downloadHandler(filename = function(){
    paste("data_analysis",gsub(":","-",Sys.time()), ".xlsx", sep="")
  },
  content=function(con)
  {file.copy(paste0(ind_code_path,'data_analysis.xlsx'),con)
  })
  
  observeEvent(input$filter,
               {
                 file_temp_name<-paste0('./work/analysis/PoPs/',input$chemicals,'_analysis.xlsx')
                 
                 if (!file.exists(file_temp_name))
                 {
                   
                   showModal(modalDialog(
                     title = "Important message",
                     "No available data",
                     easyClose = TRUE))
                 } else {
                   data_all<-read.xlsx(file_temp_name)
                   
                   data_show<-subset(data_all, Pathway %in% input$pathway)
                 
                 if (nrow(data_show)==0)
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "Pls display/update the data prior to further analysis",
                     easyClose = TRUE))
                 } else
               {
                 if (input$chem_filter!="all")
                 {data_show<-subset(data_show, Unit %in% input$unit & Congener %in% input$chem_filter & Data_Quality %in% input$data_quality)
                 } else 
                 {
            data_show<-subset(data_show,  Unit %in% input$unit & Data_Quality %in% input$data_quality)
                  
                   }
                 
                 
               if (nrow(data_show)==0)
               {
                 showModal(modalDialog(
                   title = "Important message",
                   "No available data",
                   easyClose = TRUE))
               } else {
                 updateActionButton(session,inputId="filter",label="Data Filter (Done)")
                 locationid_temp<-sort(unique(data_show$Province))
                
                 locationid<-sort(locationid_temp[which(locationid_temp!='Not specified')])
                 updateCheckboxGroupInput(session,"location_spat",label="Province",
                                          choices=locationid,selected=locationid,
                                          inline=TRUE)
                 
                 
                 updateCheckboxGroupInput(session,"location_temp",label="Province",
                                          choices=locationid_temp,selected=locationid_temp,
                                          inline=TRUE)
                 
                 yearid1<-unique(data_show$Year)
                 yearid<-as.double(unique(str_sub(yearid1,start=1,end=4)))
                 
                 updateSliderInput(session,inputId ="sample_year_temp",label="Period",
                                   min=min(yearid,na.rm=TRUE), step=1,max=max(yearid,na.rm=TRUE), value=c(min(yearid,na.rm=TRUE),max(yearid,na.rm=TRUE)))
                 
                 updateSliderInput(session,inputId ="sample_year_spat",label="Period",
                                   min=min(yearid,na.rm=TRUE), step=1,max=max(yearid,na.rm=TRUE), value=c(min(yearid,na.rm=TRUE),max(yearid,na.rm=TRUE)))
                 
                 output$liteature_data<-renderDT(
                   datatable(
                     data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                     editable = FALSE)  %>%   formatSignif(columns = c(14:19), digits = 3))  
               }
               }
               
               }
               }
               )
 
  observeEvent(input$temporal,
               {
                 file_temp_name<-paste0('./work/analysis/PoPs/',input$chemicals,'_analysis.xlsx')
                
                 if (!file.exists(file_temp_name))
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "No available data",
                     easyClose = TRUE))
                   
                 
                 } else
                 {
                   data_all<-read.xlsx(file_temp_name)
                   
                   if (input$chem_filter!="all")
                    {data_show1<-subset(data_all, Pathway %in% input$pathway & Unit %in% input$unit & Congener %in% input$chem_filter & Data_Quality %in% input$data_quality)
                   } else 
                   {
                     data_show1<-subset(data_all, Pathway %in% input$pathway & Unit %in% input$unit & Data_Quality %in% input$data_quality)
                   }
                   
                   if (nrow(data_show1)==0)
                   {
                     showModal(modalDialog(
                       title = "Important message",
                       "No available data",
                       easyClose = TRUE))
                    
                   } else
                   {
                   
                   data_show1$year_temp<-as.double(str_sub(data_show1$Year,start=1,end=4))
                   
                   data_show<-subset(data_show1, Province %in% input$location_temp & 
                                       year_temp>(as.double(input$sample_year_temp[1])-0.5) &
                                       year_temp<(as.double(input$sample_year_temp[2])+0.5))
  
                   data_show$Mean<-as.double(data_show$Mean)
                   data_show<-data_show[!is.na(data_show$Mean),]
                   filetemp=paste0(ind_code_path,'data_analysis.xlsx')
                 #  write.csv(data_show,filetemp,row.names = FALSE)
                   
                   if (nrow(data_show)==0)
                   {
                     showModal(modalDialog(
                       title = "Important message",
                       "No available data",
                       easyClose = TRUE))
                     data_show<-data.frame(info='no available data')
                  #   write.csv(data_show,filetemp123,row.names = FALSE)
                   } else {
                   
                   output$liteature_data<-renderDT(
                     datatable(
                       data_show[,c(1:(ncol(data_show)-1))],options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                       editable = FALSE)  %>%   formatSignif(columns = c(14:19), digits = 3))
                   
                   indexx<-as.double(data_show$Mean)
                   
                   
                   
                   min_value<-floor(min(log10(indexx[which(indexx>0)]),na.rm=TRUE))
                   max_value<-ceiling(max(log10(indexx[which(indexx>0)]),na.rm=TRUE))
                   
              
                   
                   seqlabel<-seq(min_value,max_value,by=max(c(1,floor((max_value-min_value)/4))))
                   ticklabel<-paste0('1E',as.character(seqlabel))
                  
                   
                   if (length(seqlabel)==1)
                   {
                     seqlabel<-seq(min_value,max_value,by=0.5)
                     ticklabel<-paste0('1E',as.character(seqlabel))
                   }
                   input_unit<-input$unit
                   input_chem_filter<-input$chem_filter
                   input_chemicals<-input$chemicals
                   input_pathway<-input$pathway
                  
                   if (input$chem_filter!='all')
                   {
                   output$plot2<-renderPlot({
                 
                     
                     ggplot(data=data_show, aes(x=as.factor(year_temp),y=log10(Mean)))+ 
                       geom_boxplot(outlier.color="black",outlier.shape=16,outlier.size=2,notch=FALSE)+
                       scale_y_continuous(breaks=seqlabel,labels=ticklabel,limits=c(min_value,max_value))+
                       labs(x='Year',y=paste0('Concentration, unit: ',input_unit), title=paste0('Temporal trend for ', input_chem_filter," in ",input_pathway))+
                       theme(title=element_text(size=14,color="Blue",face='bold'),
                             axis.title.x=element_text(size=12,face="bold",color="blue"),
                             axis.title.y=element_text(size=12,face="bold",color="blue"),
                             legend.background = element_rect(fill = NA),
                             axis.text.x=element_text(size=10,angle =315, hjust = 0.5),axis.text.y=element_text(size=12)
                       )+
                       theme(panel.border = element_blank(), panel.background = element_blank(),
                             panel.grid.major = element_blank(),panel.grid.minor = element_blank(),
                             axis.line.y.left =  element_line(color='black'),
                            
                             axis.line.x.bottom =  element_line(color='black'))
                     },height = 400,width = 500)
                   } else
                   {
                     
                     output$plot2<-renderPlot({
                       
                       
                       ggplot(data=data_show, aes(x=as.factor(year_temp),y=log10(Mean)))+ 
                         geom_boxplot(outlier.color="black",outlier.shape=16,outlier.size=2,notch=FALSE)+
                         scale_y_continuous(breaks=seqlabel,labels=ticklabel,limits=c(min_value,max_value))+
                         labs(x='Year',y=paste0('Concentration, unit: ',input_unit), title=paste0('Temporal trend for ', input_chemicals," in ",input_pathway))+
                         theme(title=element_text(size=14,color="Blue",face='bold'),
                               axis.title.x=element_text(size=12,face="bold",color="blue"),
                               axis.title.y=element_text(size=12,face="bold",color="blue"),
                               legend.background = element_rect(fill = NA),
                               axis.text.x=element_text(size=10,angle =315, hjust = 0.5),axis.text.y=element_text(size=12)
                         )+
                         
                         theme(panel.border = element_blank(), panel.background = element_blank(),
                               panel.grid.major = element_blank(),panel.grid.minor = element_blank(),
                               axis.line.y.left =  element_line(color='black'),
                               axis.line.x.bottom =  element_line(color='black'))
                     },height = 400,width = 500)
                   }
                   } 
                   }
               }
               }
  )
  
  observeEvent(input$pathway,
             {
               updateActionButton(session,inputId="filter",label="Data Filter (Not done)")
               updateActionButton(session,inputId="data_shown",label="Data Selection (Not done)")
             })
  
  observeEvent(input$chem_filter,
               {
                 updateActionButton(session,inputId="filter",label="Data Filter (Not done)")

               })
  observeEvent(input$unit,
               {
                 updateActionButton(session,inputId="filter",label="Data Filter (Not done)")

               })
  
  observeEvent(input$data_quality,
               {
                 updateActionButton(session,inputId="filter",label="Data Filter (Not done)")
                 
               })
  
  observeEvent(input$chemicals,
             {
               updateActionButton(session,inputId="filter",label="Data Filter (Not done)")
               updateActionButton(session,inputId="data_shown",label="Data Selection (Not done)")
             })
               
               
  
  observeEvent(input$data_shown,
               {
                 output$title_pollutant<-renderUI({(h3("Exposure data for selected PoPs"))})
                 filetemp123=paste0(ind_code_path,'data_analysis.xlsx')
       file_temp_name<-paste0('./work/analysis/PoPs/',input$chemicals,'_analysis.xlsx')
       updateActionButton(session,inputId="filter",label="Data Filter (Not done)")
        if (!file.exists(file_temp_name))
                 {
                   
                   showModal(modalDialog(
                     title = "Important message",
                     "No available data",
                     easyClose = TRUE))
          data_show<-data.frame(info='no available data')
          write.xlsx(data_show,filetemp123)
                 } else
                 {
                   data_all<-read.xlsx(file_temp_name)
                   
                      data_show<-subset(data_all, Pathway %in% input$pathway)
                       if (nrow(data_show)==0)
                      {
                         showModal(modalDialog(
                           title = "Important message",
                           "No available data",
                           easyClose = TRUE))
                         data_show<-data.frame(info='no available data')
                         write.xlsx(data_show,filetemp123)
                        
                      } else {
                   # data_show<-data_all
                   locationid_temp<-sort(unique(data_show$Province))
                   locationid<-sort(locationid_temp[which(locationid_temp!='Not specified')])
                   unit_unique<-unique(data_show$Unit)
                   unit_no<-rep(1,length(unit_unique))
                   for (i in 1:length(unit_unique))
                   {
                     unit_no[i]=length(which(data_show$Unit==unit_unique[i]))
                   }
                   
                  
                   
                   data_unit<-data.frame(unit=unit_unique,no=unit_no)
                   data_unit<-data_unit[order(data_unit$no, decreasing = TRUE),]
                   
                   updateCheckboxGroupInput(session,"location_spat",label="Province",
                                            choices=locationid,selected=locationid,
                                            inline=TRUE)
                  
                
                     updateCheckboxGroupInput(session,"location_temp",label="Province",
                                              choices=locationid_temp,selected=locationid_temp,
                                              inline=TRUE)
                     if (length(unique(data_show$Congener))>1)
                     {
                     chemical_list_filter<-c('all',unique(data_show$Congener))} else 
                     
                     {
                       chemical_list_filter<-unique(data_show$Congener)
                     }
      
                    # print(unique(data_show$chemicals))
                     
                      updateSelectInput(session,'chem_filter', label='Congener filter',choices=chemical_list_filter, 
                                        selected=chemical_list_filter[1])
                    
                      if (input$groups!='Dioxins and PCBs' & input$chemicals!='Polychlorinated naphthalenes')
                      {
                      
                     if (input$pathway=='air' |input$pathway=='water')
                     {
                      
                     updateSelectInput(session,'unit', label='Unit filter',choices=data_unit$unit[1],
                                    selected=data_unit$unit[1])
                      
                       
                       } else if  (input$pathway=='dust' | input$pathway=='sediment' | input$pathway=='soil')
                       {
                         if (nrow(data_unit)>1)
                         {
                         updateSelectInput(session,'unit', 'Unit filter',choices=data_unit$unit[1:2], 
                                           selected=data_unit$unit[1])
                         } else 
                         {
                           updateSelectInput(session,'unit', 'Unit filter',choices=data_unit$unit[1], 
                                             selected=data_unit$unit[1])
                         }
                       } else 
                       {
                         if  (nrow(data_unit)>3)
                         {
                         updateSelectInput(session,'unit', 'Unit filter',choices=data_unit$unit[1:4], 
                                           selected=data_unit$unit[1])
                       } else 
                       {
                         updateSelectInput(session,'unit', 'Unit filter',choices=data_unit$unit[1:nrow(data_unit)], 
                                           selected=data_unit$unit[1]) 
                       }
                       }
                      } else 
                      {
                        updateSelectInput(session,'unit', label='Unit filter',choices=data_unit$unit,
                                          selected=data_unit$unit[1])
                       
                      }
                   yearid1<-unique(data_show$Year)
                  yearid<-as.double(unique(str_sub(yearid1,start=1,end=4)))
                  
                updateSliderInput(session,inputId ="sample_year_temp",label="Period",
                                  min=min(yearid,na.rm=TRUE), step=1,max=max(yearid,na.rm=TRUE), value=c(min(yearid,na.rm=TRUE),max(yearid,na.rm=TRUE)))
                   
                updateSliderInput(session,inputId ="sample_year_spat",label="Period",
                                  min=min(yearid,na.rm=TRUE), step=1,max=max(yearid,na.rm=TRUE), value=c(min(yearid,na.rm=TRUE),max(yearid,na.rm=TRUE)))
                
                filetemp=paste0(ind_code_path,'data_analysis.xlsx')
                   write.xlsx(data_show,filetemp)
                   updateActionButton(session,inputId="data_shown",label="Data Selection (Done)"
                   )  
                   
                   output$liteature_data<-renderDT(
                     datatable(
                       data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                       editable = FALSE)  %>%   formatSignif(columns = c(14:19), digits = 3))
                   
                 } 
               }
                 
               }
  )
  
  observeEvent(input$spatial,
               {
                 file_temp_name<-paste0('./work/analysis/PoPs/',input$chemicals,'_analysis.xlsx')
                 if (!file.exists(file_temp_name))
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "No available data",
                     easyClose = TRUE))
                 } else
                 {
                   data_all<-read.xlsx(file_temp_name)
                   
                   if (input$chem_filter!="all")
                   {data_show1<-subset(data_all, Pathway %in% input$pathway & Unit %in% input$unit & Congener %in% input$chem_filter & Data_Quality %in% input$data_quality)
                   } else 
                   {
                     data_show1<-subset(data_all, Pathway %in% input$pathway & Unit %in% input$unit & Data_Quality %in% input$data_quality)
                   }
                   
                   if (nrow(data_show1)==0)
                   {
                     showModal(modalDialog(
                       title = "Important message",
                       "No available data",
                       easyClose = TRUE))
                   } else
                   {
                   
                   data_show1$year_temp<-as.double(str_sub(data_show1$Year,start=1,end=4))
                   
                   data_show<-subset(data_show1, Province %in% input$location_spat & 
                                       year_temp>(as.double(input$sample_year_spat[1])-0.5) &
                                       year_temp<(as.double(input$sample_year_spat[2])+0.5))
                   
                   if (nrow(data_show)==0)
                   {
                     showModal(modalDialog(
                       title = "Important message",
                       "No available data",
                       easyClose = TRUE))
                   } else
                   {
                   data_show$Mean<-as.double(data_show$Mean)
                   data_show<-data_show[!is.na(data_show$Mean),]
                   
                   china_map<-read_excel('./work/analysis/china_map.xlsx')
                   
                   
                   data_all1<-as.data.frame(tapply(data_show$Mean,as.factor(data_show$Province),median))
                   
                   data_all2<-data.frame(namecn=rownames(data_all1),concentration=data_all1[,1])
                   
                   
                   data_all3<-data_all2[!is.na(data_all2$concentration),]
                   data_all3$logconcentration<-log10(data_all3$concentration)
                   data_all4<-data_all3[,c(1,3)]
                   
                   if (nrow(data_all3)>8)
                   {
                     index<-which(data_all3$logconcentration>quantile(data_all3$logconcentration,0.25)[[1]]-
                                    2.5*IQR(data_all3$logconcentration) & data_all3$logconcentration<quantile(data_all3$logconcentration,0.75)[[1]]+
                                    2.5*IQR(data_all3$logconcentration))
                     data_all4<-data_all3[index,c(1,3)]
                   }
                   
                   data_all2<-merge(data_all2,data_all4, by='namecn',all.x=TRUE)
                   
                   if (nrow(data_all2)==0)
                   {
                     showModal(modalDialog(
                       title = "Important message",
                       "No available data",
                       easyClose = TRUE))
                   } else 
                   {
                   
                   plot_data<-join(china_map, data_all2, type="left")
                   
                   
                   min_value<-floor(min(plot_data$logconcentration,na.rm=TRUE))
                   max_value<-ceiling(max(plot_data$logconcentration,na.rm=TRUE))
                   
                   
                   seqlabel<-seq(min_value,max_value,by=max(c(1,floor((max_value-min_value)/4))))
                   ticklabel<-paste0('1E',as.character(seqlabel))
                 
                   if (input$chem_filter!='all')
                   {
                     title_name=input$chem_filter
                   } else 
                   {
                     title_name=input$chemicals
                   }
                 input_unit<-input$unit
                 input_pathway<-input$pathway
                   output$plot3<-renderPlot({ ggplot(plot_data,aes(x=long,y=lat,group=group,fill=logconcentration))+
                     geom_polygon(colour="black",na.rm=TRUE)+
                     scale_fill_gradient(low="white",high="red",limits=c(min_value,max_value),
                                        breaks=seqlabel, labels=ticklabel, name='level')+
                     coord_map("polyconic")+labs(title=paste0('Spatial distribution for ',title_name," in ", input_pathway, " (unit: ",input_unit,")"),
                                                 x=NULL,y=NULL)+
                     theme(
                       
                       axis.text=element_blank(),
                       axis.ticks=element_blank(),
                       axis.title=element_blank(),
                       legend.position=c(0.25,0.2),
                       plot.background = element_rect(fill = "transparent", colour = "transparent"),
                       panel.background = element_rect(fill = "transparent", colour = "transparent"),
                       panel.grid = element_blank(),
                       title=element_text(size=14,face='bold')
                       
                     )},height = 400,width = 500)
                   
               #    plot_data<-join(china_map, data_all2, type="left")
                   
                   
                   
                 #  plot_data$concentration[is.na(plot_data$concentration)]<-0
                  
               #    filetemp=paste0(ind_code_path,'data_analysis.csv')
                 #  write.csv(data_show,filetemp,row.names = FALSE)
                   output$liteature_data<-renderDT(
                     datatable(
                       data_show[,c(1:(ncol(data_show)-1))],options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                       editable = FALSE)  %>%   formatSignif(columns = c(14:19), digits = 3))
                   
                   }
                   }
                 } 
                 
               }
}
  )
  
}


#-------human health risk assessment-------------
#Ui/Server for risk assessment

 Module_hhra_Ui<-function(id){
  ns <- NS(id)
  tabItem(tabName = "hhra",
          fluidPage(
            fluidRow(
            box(title = "Step 1. Chemical Selection", width =3, solidHeader = TRUE, status = "primary",
                collapsible=TRUE, collapsed=FALSE,
                selectInput(ns('groups'),"Group",choices=group_list,selected='OCPs'),
                selectInput(ns('chemicals'), 'Chemical',choices=OCP_list, selected=OCP_list[1]
                ),
              #  checkboxGroupInput(ns('pathway'), label="Pathway", choices=pathway_hhra, selected=pathway_hhra,inline=TRUE),
            
                actionBttn(ns("data_shown"), label='Data Selection (Not done)',color = "primary",style = "gradient",size='md')  
                # 
                # br(),
                # br(),
                # 
                # downloadBttn(ns('data_shown_download'),label='Data Download',size='xs',color="success",style='pill'),
                
            ),
            box(title = "Step 2. Data Filter", width =3, solidHeader = TRUE, status = "primary",
                collapsible=TRUE, collapsed=FALSE,
               
                selectInput(ns('chem_filter'), label='Congener filter',choices=c('all'), selected='all'),
                checkboxGroupInput(ns('data_quality'), label='Data quality filter',choices=quality_list, selected=quality_list,
                                   inline=TRUE
                ),
                checkboxGroupInput(ns('pathway'), label="Pathway selection", choices=pathway_hhra, selected=pathway_hhra,inline=TRUE),
            
                
                 actionBttn(ns("filter"), label='Data Filter (Not done)',color = "primary",style = "gradient",size='md')  


            ),
            
            box(title = "Step 3. Exposure Data Summary", width = 3, solidHeader = TRUE,status = "primary",
                collapsible=TRUE, collapsed=FALSE,
                #  selectInput(ns('data_consumption_input'), 'Consumption data',c("example"='example',"manually"="manually"), width = 120),
                #  conditionalPanel(condition=paste0("input['", ns("data_consumption_input"), "'] == 'manually' "),
                #                  numericInput(ns("num_data_consumption"), 'The number of population groups',2,step=1,width=150,min=3,max=Inf)),
                #  conditionalPanel(condition=paste0("input['", ns("data_consumption_input"), "'] == 'manually' "),
                #                  actionButton(ns("gen_data_consumption"), 'Clcik to genearte data',width=180,style="color: #FFFFFF; background-color: #4783b3; border-color: #4783b3")),
                
                sliderInput(ns("sample_year"),label="Period",min=1980, max=2025, value=c(2000,2020)),
                
                checkboxGroupInput(ns("location"), label="Province",choices=c('National'), selected=c('National')),
                actionBttn(ns("exposure"), label='Exposure Data Summary (Not done)',color = "primary",style = "gradient",size='sm')
            ),
            box(title = "Step 4. Risk Estimation", width = 3, solidHeader = TRUE, status = "primary",
                collapsible=TRUE, collapsed=FALSE,
              
                numericInput(ns('rfd'), label='Reference dose (ng/kg/day)', value=100, step=1, min=1),
                br(),
                actionBttn(ns("consumption"), label='Edit Consumption Data (Not done)',color = "primary",style = "gradient",size='sm'),
                br(),
                
                br(),
                actionBttn(ns("run"), label='Risk Estimation (Not done)',color = "success",style = "gradient",size='md')
                
            )
            ),
           
            fluidRow(uiOutput(ns("title_consump_data"))),
            fluidRow(DT::dataTableOutput(ns("consump_data"))),
            fluidRow(uiOutput(ns("title_liteature_data"))),
            fluidRow(DT::dataTableOutput(ns("liteature_data")))

          )
  )
}



 Module_hhra_Server <- function(input, output, session){
#  
  
   
  observeEvent(input$groups,
               {
         updateActionButton(session,inputId="data_shown",label="Data Selection (Not done)")
           updateActionButton(session,inputId="filter",label="Data Filter (Not done)")
           updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Not done)")
            updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
            updateActionButton(session,inputId="exposure",label="Exposure Data Summary (Not done)")
                 if (input$groups=='OCPs')
                 {
                   updateSelectInput(session,'chemicals', 'Chemical',choices=OCP_list,
                                     selected=OCP_list[1])

                 } else if (input$groups=='Dioxins and PCBs')
                 {
                   updateSelectInput(session,'chemicals','Chemical',choices=PCDD_list, selected=PCDD_list[1])
                 } else if (input$groups=='BFRs')
                 {
                   updateSelectInput(session,'chemicals','Chemical',choices=BFR_list, selected=BFR_list[1])
                 } else if (input$groups=='PFASs')
                 {
                   updateSelectInput(session,'chemicals','Chemical',choices=PFAS_list, selected=PFAS_list[1])
                 } else if (input$groups=='Other POPs')
                 {
                   updateSelectInput(session,'chemicals','Chemical',choices=Others_list, selected=Others_list[1])
                 }
               }
  )
   
   observeEvent(input$chemicals, {
     updateActionButton(session,inputId="data_shown",label="Data Selection (Not done)")
     updateActionButton(session,inputId="filter",label="Data Filter (Not done)")
     updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Not done)")
     updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
     updateActionButton(session,inputId="exposure",label="Exposure Data Summary (Not done)")
     
     file_temp_name<-paste0('./work/hhra/toxicity.xlsx')
     data_all<-read.xlsx(file_temp_name)
     data_seb<-subset(data_all, chemicals %in% input$chemicals)
     updateNumericInput(session,'rfd',label=paste0('Reference dose (ng/kg/day) for ',input$chemicals), value=as.double(data_seb$value[1]))
   })
   observeEvent(input$data_shown,
                {
                  file_temp_name<-paste0('./work/analysis/PoPs/',input$chemicals,'_analysis.xlsx')
                  
                  updateActionButton(session,inputId="filter",label="Data Filter (Not done)")
                  updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Not done)")
                  updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
                  updateActionButton(session,inputId="exposure",label="Exposure Data Summary (Not done)")
                  
                  filetemp123=paste0(ind_code_path,'data_exposure_temp.csv')
                  if (!file.exists(file_temp_name))
                  {
                    
                    showModal(modalDialog(
                      title = "Important message",
                      "No available data",
                      easyClose = TRUE))
                    
                    data_show<-data.frame(info='no available data')
                    write.csv(data_show,filetemp123,row.names = FALSE)
                  } else
                  {
                    data_all<-read.xlsx(file_temp_name)
                    data_show<-subset(data_all, Pathway %in% pathway_hhra)
                    if (nrow(data_show)==0)
                    {
                      showModal(modalDialog(
                        title = "Important message",
                        "No available data",
                        easyClose = TRUE))
                      data_show<-data.frame(info='no available data')
                      write.csv(data_show,filetemp123,row.names = FALSE)
                      
                    }   else {
                      
                      
                      data_show1<-NULL
                      
                      for (i in 1:length(pathway_hhra))
                      { data_show2<-subset(data_show, Pathway %in% pathway_hhra[i] &
                                             Unit %in% pathway_hhra_unit[i])
                      data_show1<-rbind(data_show2,data_show1)}
                      
                      if (nrow(data_show1)==0)
                      {
                        showModal(modalDialog(
                          title = "Important message",
                          "No available data",
                          easyClose = TRUE))
                        
                        data_show<-data.frame(info='no available data')
                        write.csv(data_show,filetemp123,row.names = FALSE)
                      } else 
                      {
                        
                        data_show<-data_show1
                        # print(data_show)
                        pathway_temp<-unique(data_show$Pathway)
                        updateCheckboxGroupInput(session, inputId='pathway',
                                                 label="Pathway selection", choices=pathway_temp, selected=pathway_temp, inline = TRUE)
                        
                        
                        if (length(unique(data_show$Congener))>1)
                        {
                          chemical_list_filter<-c('all',unique(data_show$Congener))} else 
                            
                          {
                            chemical_list_filter<-unique(data_show$Congener)
                          }
                        
                        # print(unique(data_show$chemicals))
                        
                        updateSelectInput(session,'chem_filter', label='Congener filter',choices=chemical_list_filter, 
                                          selected=chemical_list_filter[1])
                        
                        
                        
                        locationid_temp<-sort(unique(data_show$Province))
                        
                        updateCheckboxGroupInput(session,"location",label="Province",
                                                 choices=locationid_temp,selected=locationid_temp,
                                                 inline=TRUE)
                        
                        
                        yearid1<-unique(data_show$Year)
                        yearid<-as.double(unique(str_sub(yearid1,start=1,end=4)))
                        # print(yearid)
                        # print(locationid_temp)
                        updateSliderInput(session,inputId ="sample_year",label="Period",
                                          min=min(yearid,na.rm=TRUE), step=1,max=max(yearid,na.rm=TRUE), value=c(min(yearid,na.rm=TRUE),max(yearid,na.rm=TRUE)))
                        
                        data_show$Mean<-as.double(data_show$Mean)
                        data_show<-data_show[!is.na(data_show$Mean),] #duplicated is.na
                        # print(data_show)
                        #write.csv(data_show,'data_test.csv')
                        
                        # print(data_all2)
                        
                        if (nrow(data_show)==0)
                        {
                          showModal(modalDialog(
                            title = "Important message",
                            "No available data",
                            easyClose = TRUE))
                          
                          data_show<-data.frame(info='no available data')
                          write.csv(data_show,filetemp123,row.names = FALSE)
                        } else
                        {
                          chemicals_name<-input$chemicals
                          updateActionButton(session,inputId="data_shown",label="Data Selection (Done)")
                          output$title_liteature_data<-renderUI({mainPanel(h3(paste0("Exposure data for ", chemicals_name)))})
                          write.csv(data_show,filetemp123,row.names = FALSE)
                          output$liteature_data<-renderDT(
                            datatable(
                              data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                              editable = FALSE)  %>%   formatSignif(columns = c(14:19), digits = 3))
                          
                          # filetemp_write1=paste0(ind_code_path,'_hhra_exposure_write.xlsx')
                          # write.xlsx(data_all2,filetemp_write1,row.names = FALSE)
                          
                        }
                      }
                    }
                  }
                }
   )
   
   observeEvent(input$chem_filter, {
   
     updateActionButton(session,inputId="filter",label="Data Filter (Not done)")
     updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Not done)")
     updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
     updateActionButton(session,inputId="exposure",label="Exposure Data Summary (Not done)")
     
   #  file_temp_name<-paste0(ind_code_path,'data_exposure_temp_123.csv')
     file_temp<-paste0(ind_code_path,'data_exposure_temp.csv')
     
     if (!file.exists(file_temp))
     {
       
       # showModal(modalDialog(
       #   title = "Important message",
       #   "Pls select Chemical prior to further analysis",
       #   easyClose = TRUE))
       
     } else {
       data_all<-read.csv(file_temp)
       # print(data_all)
       if (colnames(data_all)[1]=='info')
       {
         showModal(modalDialog(
           title = "Important message",
           "No available data",
           easyClose = TRUE))
         
         data_show<-data.frame(info='no available data')
        
         
       } else {
         data_show<-data_all
         if (input$chem_filter!="all")
         {data_show<-subset(data_show, Congener %in% input$chem_filter)
         } else 
         {
           data_show<-subset(data_show)
           
           
         }
         
       
         
         
         if (nrow(data_show)==0)
         {
           showModal(modalDialog(
             title = "Important message",
             "No available data",
             easyClose = TRUE))
           data_show<-data.frame(info='no available data')
          
         } else
         {
           
           
           updateCheckboxGroupInput(session,'data_quality', label='Data quality filter',choices=sort(unique(data_show$Data_Quality)), 
                                    selected=sort(unique(data_show$Data_Quality)), inline=TRUE)
          

         
      
           
           updateCheckboxGroupInput(session,'pathway', label='Pathway selection',choices=sort(unique(data_show$Pathway)), 
                                    selected=sort(unique(data_show$Pathway)), inline=TRUE)   
   
           
         }
       }
       
       
     }
   
 
     
   })
   

   
   observeEvent(input$data_quality, {
     
     updateActionButton(session,inputId="filter",label="Data Filter (Not done)")
     updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Not done)")
     updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
     updateActionButton(session,inputId="exposure",label="Exposure Data Summary (Not done)")
     
    
     
    
     file_temp<-paste0(ind_code_path,'data_exposure_temp.csv')
    
  
     if (!file.exists(file_temp))
     {
       
       # showModal(modalDialog(
       #   title = "Important message",
       #   "Pls select Chemical prior to further analysis",
       #   easyClose = TRUE))
       
     } else {
       data_all<-read.csv(file_temp)
       # print(data_all)
       if (colnames(data_all)[1]=='info')
       {
         showModal(modalDialog(
           title = "Important message",
           "No available data",
           easyClose = TRUE))
         
         data_show<-data.frame(info='no available data')
         
         
       } else {
         data_show<-data_all
         if (input$chem_filter!="all" & length(input$data_quality)>0)
         {
         
           data_show<-subset(data_show, Congener %in% input$chem_filter & Data_Quality %in% input$data_quality)
         } else if (input$chem_filter=="all" & length(input$data_quality)>0)
         {
           
           data_show<-subset(data_show, Data_Quality %in% input$data_quality)
         } 
         
   
     
         
         if (nrow(data_show)==0)
         {
           showModal(modalDialog(
             title = "Important message",
             "No available data",
             easyClose = TRUE))
           data_show<-data.frame(info='no available data')
           
      
           
         } else
         {
           
           
         
           
           updateCheckboxGroupInput(session,'pathway', label='Pathway selection',choices=sort(unique(data_show$Pathway)), 
                                    selected=sort(unique(data_show$Pathway)), inline=TRUE)   
           

         }
       }
       
     }
     if (is.null(input$data_quality))
     {
       showModal(modalDialog(
         title = "Important message",
         "Pls select at least one option for data quality",
         easyClose = TRUE))
       
       updateCheckboxGroupInput(session,'pathway', label='Pathway selection',choices=character(0), 
                                selected=character(0), inline=TRUE)  
     }
       
       
     
      },ignoreNULL = FALSE)
   
   observeEvent(input$pathway, {
     
     updateActionButton(session,inputId="filter",label="Data Filter (Not done)")
     updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Not done)")
     updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
     updateActionButton(session,inputId="exposure",label="Exposure Data Summary (Not done)")
     
     if (is.null(input$data_quality))
     {
       
       showModal(modalDialog(
         title = "Important message",
         "Pls select at least one option for data quality",
         easyClose = TRUE))
     }
     
     if (is.null(input$pathway))
     {
       showModal(modalDialog(
         title = "Important message",
         "Pls select at least one option for pathway",
         easyClose = TRUE))
     }
   },ignoreNULL = FALSE)
   
   observeEvent(input$filter,
                {
                  file_temp_name<-paste0(ind_code_path,'data_exposure_temp_123.csv')
                  file_temp<-paste0(ind_code_path,'data_exposure_temp.csv')
                  
                  
                  updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Not done)")
                  updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
                  updateActionButton(session,inputId="exposure",label="Exposure Data Summary (Not done)")
                  
                  if (is.null(input$data_quality))
                  {
                   
                    showModal(modalDialog(
                      title = "Important message",
                      "Pls select at least one option for data quality",
                      easyClose = TRUE))
                  } else {
               
                    if (is.null(input$pathway))
                    {
                      
                      showModal(modalDialog(
                        title = "Important message",
                        "Pls select at least one option for pathway",
                        easyClose = TRUE))
                    } else {
                  if (!file.exists(file_temp))
                  {
                    
                    showModal(modalDialog(
                      title = "Important message",
                      "Pls select Chemical prior to further analysis",
                      easyClose = TRUE))
                    
                  } else {
                    data_all<-read.csv(file_temp)
                    # print(data_all)
                    if (colnames(data_all)[1]=='info')
                    {
                      showModal(modalDialog(
                        title = "Important message",
                        "No available data",
                        easyClose = TRUE))
                      
                      data_show<-data.frame(info='no available data')
                      write.csv(data_show,file_temp_name,row.names = FALSE)
                      
                    } else {
                      data_show<-data_all
                      if (input$chem_filter!="all")
                      {data_show<-subset(data_show, Pathway %in% input$pathway & Congener %in% input$chem_filter & Data_Quality %in% input$data_quality)
                      } else 
                      {
                        data_show<-subset(data_show,  Pathway %in% input$pathway & Data_Quality %in% input$data_quality)
                        
                      }
                      
                      
                      if (nrow(data_show)==0)
                      {
                        showModal(modalDialog(
                          title = "Important message",
                          "No available data",
                          easyClose = TRUE))
                        data_show<-data.frame(info='no available data')
                        write.csv(data_show,file_temp_name,row.names = FALSE)
                      } else
                      {
                        
                        updateActionButton(session,inputId="filter",label="Data Filter (Done)")
                        
                        
                        
                        locationid_temp<-sort(unique(data_show$Province))
                        
                        updateCheckboxGroupInput(session,"location",label="Province",
                                                 choices=locationid_temp,selected=locationid_temp,
                                                 inline=TRUE)
                        
                        
                        yearid1<-unique(data_show$Year)
                        yearid<-as.double(unique(str_sub(yearid1,start=1,end=4)))
                        # print(yearid)
                        # print(locationid_temp)
                        updateSliderInput(session,inputId ="sample_year",label="Period",
                                          min=min(yearid,na.rm=TRUE), step=1,max=max(yearid,na.rm=TRUE), value=c(min(yearid,na.rm=TRUE),max(yearid,na.rm=TRUE)))
                        
                        
                        if (input$chem_filter=="all")
                        {
                          chemicals_name<-input$chemicals
                        } else 
                        {
                          chemicals_name<-input$chem_filter
                        }
                        output$title_liteature_data<-renderUI({mainPanel(h3(paste0("Exposure data for ", chemicals_name)))})
                        write.csv(data_show,file_temp_name,row.names = FALSE)
                        output$liteature_data<-renderDT(
                          datatable(
                            data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                            editable = FALSE)  %>%   formatSignif(columns = c(14:19), digits = 3))
                        
                      }
                    }
                    
                    
                  }
                }
 
                  }    
                }
               
   )
   
   observeEvent(input$sample_year, {
     
     updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Not done)")
     updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
     updateActionButton(session,inputId="exposure",label="Exposure Data Summary (Not done)")
     
   })
   
   observeEvent(input$location, {
     updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Not done)")
     updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
     updateActionButton(session,inputId="exposure",label="Exposure Data Summary (Not done)")
     
   })
   
   
   observeEvent(input$exposure,
                {
                  file_temp_name<-paste0(ind_code_path,'data_exposure_temp_234.csv')
                  file_temp<-paste0(ind_code_path,'data_exposure_temp_123.csv')
                  updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Not done)")
                  updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
                
                  if (!file.exists(file_temp))
                  {
                    
                    showModal(modalDialog(
                      title = "Important message",
                      "Pls finsih prior step before further analysis",
                      easyClose = TRUE))
                    
                  } else {
                  data_all<-read.csv(file_temp)
                    
                    if (colnames(data_all)[1]=='info')
                    {
                      showModal(modalDialog(
                        title = "Important message",
                        "No available data",
                        easyClose = TRUE))
                      
                      data_show<-data.frame(info='no available data')
                      write.csv(data_show,file_temp_name,row.names = FALSE)
                      
                    } else {
                      data_show<-data_all
                      
                      data_show$year_temp<-as.double(str_sub(data_show$Year,start=1,end=4))
                      
                      data_show<-subset(data_show, Province %in% input$location & 
                                          year_temp>(as.double(input$sample_year[1])-0.5) &
                                          year_temp<(as.double(input$sample_year[2])+0.5))
                      
                      
                      if (nrow(data_show)==0)
                      {
                        showModal(modalDialog(
                          title = "Important message",
                          "No available data",
                          easyClose = TRUE))
                        data_show<-data.frame(info='no available data')
                        write.csv(data_show,file_temp_name,row.names = FALSE)
                      } else
                      {
                        chemicals_name<-input$chemicals
                    data_all1<-as.data.frame(tapply(data_show$Mean,as.factor(data_show$Pathway),median))
                   data_allmin<-as.data.frame(tapply(data_show$Mean,as.factor(data_show$Pathway),min))
                  data_allmax<-as.data.frame(tapply(data_show$Mean,as.factor(data_show$Pathway),max))
                #  print(data_all1)
                   data_all2<-data.frame(chemicals=rep(chemicals_name,nrow(data_all1)),Pathway=rownames(data_all1),median_of_average=data_all1[,1],
                     min_of_average=data_allmin[,1],max_of_average=data_allmax[,1])
                   
                   data_unit_pathway<-data.frame(Pathway=pathway_hhra, Unit=pathway_hhra_unit)
                   data_all3<-merge(data_all2,data_unit_pathway,by='Pathway',all.x=TRUE)
                   data_all4<-data_all3[,c(2,1,ncol(data_all3),3:5)]
                   #  print(data_all3)
                        
                        updateActionButton(session,inputId="exposure",label="Exposure Data Summary (Done)")
                       
                        if (input$chem_filter=="all")
                        {
                          chemicals_name<-input$chemicals
                        } else 
                        {
                          chemicals_name<-input$chem_filter
                        }
                       
                        
                        output$title_liteature_data<-renderUI({mainPanel(h3(paste0("The summary on exposure data for ", chemicals_name)))})
                       
                         write.csv(data_all4,file_temp_name,row.names = FALSE)
                        output$liteature_data<-renderDT(
                          datatable(
                            data_all4,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                            editable = FALSE)  %>%   formatSignif(columns = c(4:6), digits = 3))
                        
                      }
                    }
                    
                    
                  }
                }
   )
   
   observeEvent(input$rfd,
                {
                  updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
                })
   

   observeEvent(input$consumption,
                {
                  
                  file_temp<-paste0(ind_code_path,'data_exposure_temp_234.csv')
                 
                  updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
                  
                  if (!file.exists(file_temp))
                  {
                    
                    showModal(modalDialog(
                      title = "Important message",
                      "Pls summary the exposure data prior to further analysis",
                      easyClose = TRUE))
                    
                  } else 
                  {
                 data_exposure<-read.csv(file_temp)
                 if (colnames(data_exposure)[1]=='info' | nrow(data_exposure)==0 )
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "No available exposure data for further analysis",
                     easyClose = TRUE))
                   
                 } else {
                   output$title_consump_data<-renderUI({mainPanel(h3("The consumption rate for various pathways"))})
                   updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Done)")
                   updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
                   file_temp_name<-paste0('./work/hhra/consumpation.xlsx')
                   data_all_consumption<-read.xlsx(file_temp_name)
                   
                   pathway_consump<-c(unique(as.character(data_exposure$Pathway)),'body weight')
                  # print(data_all_consumption)
                 #  print(pathway_consump)
                   data_show<-subset(data_all_consumption, Pathway %in% pathway_consump)
                    
                  output$consump_data<-renderDT(
                    datatable(
                      data_show[,1:3],options = list(lengthMenu=c('10','20'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                      editable = TRUE)  %>%   formatSignif(columns = c(2), digits = 3))
                  filetemp_write1=paste0(ind_code_path,'_hhra_temp_consump_write.xlsx')
                  write.xlsx(data_show,filetemp_write1,row.names = FALSE)
                 }
                  }
                })
   
   observeEvent(input$consump_data_cell_edit,  
                {
     
  
     filetemp_write1=paste0(ind_code_path,'_hhra_temp_consump_write.xlsx')
     data_show<-(read_excel(filetemp_write1))
    
     
     info = input$consump_data_cell_edit
     i = info$row
     j = info$col+1
  
     v = info$value
    
     data_show[i, j]<- as.double(v)
    
     write.xlsx(data_show,filetemp_write1,row.names = FALSE)
   }
   )

   observeEvent(input$run,{
     file_temp_consump<-paste0(ind_code_path,'_hhra_temp_consump_write.xlsx')
     file_temp_exposure<-paste0(ind_code_path,'data_exposure_temp_234.csv')
     
     if (!file.exists(file_temp_exposure))
     {
       
       showModal(modalDialog(
         title = "Important message",
         "Pls summary the exposure data prior to risk estimation",
         easyClose = TRUE))
       
     } else {
       
       if (!file.exists(file_temp_consump))
       {
         showModal(modalDialog(
           title = "Important message",
           "Pls edit the consumption data prior to risk estimation",
           easyClose = TRUE))
       } else {
         
     data_exposure<-read.csv(file_temp_exposure)
     data_consumption<-read.xlsx(file_temp_consump)
     
     if (nrow(data_exposure)==0 | nrow(data_consumption)==0 | colnames(data_exposure)[1]=='info' | colnames(data_consumption)[1]=='info')
     
     {
       showModal(modalDialog(
         title = "Important message",
         "No available data",
         easyClose = TRUE))
     } else {
     data_merge<-merge(data_exposure[,c(1, 2,3,4)],data_consumption,by='Pathway')
    
     data_bw<-subset(data_consumption, Pathway %in% 'body weight')
     
   
     data_merge$daily_intake<-as.double(data_merge$median_of_average)*as.double(data_merge$Consumption_Rate)/
       as.double(data_bw$Consumption_Rate)
       data_merge$risk<-data_merge$daily_intake/as.double(input$rfd)
      
       data_show<-data_merge[,c(1,7,8)]
     # # 
       data_temp<-data.frame(Pathway='All',daily_intake=sum(data_show$daily_intake,na.rm=TRUE),risk=
                   sum(data_show$risk,na.rm=TRUE))
       
     # 
     data_show<-rbind(data_show,data_temp)
     
     data_merge$median_of_average=paste0(as.character(signif(data_merge$median_of_average,2)),' ',data_merge[,3])
     data_merge$Consumption_Rate=paste0(as.character(signif(data_merge$Consumption_Rate,2)),' ',data_merge[,6])
     
     data_show1<-merge(data_show,data_merge[,c(1,2,4,5)],by='Pathway',all.x=TRUE)
     
     data_show2<-data_show1[,c(4,1,5,6,2,3)]
     
     colnames(data_show2)[1:6]<-c('Chemicals',"Pathway",'Concentration','Consumption_Rate','Daily_Intake(ng/kg/day)',"Risk")
     
    data_show2$Chemicals[nrow(data_show2)]<-data_show2$Chemicals[nrow(data_show2)-1]
    
    if (input$chem_filter=="all")
    {
      input_chem<-input$chemicals
    } else 
    {
      input_chem<-input$chem_filter
    }
    output$title_consump_data<-renderUI({mainPanel(h3(paste0("Risk estimation for ", input_chem)))})
    updateActionButton(session,inputId="run",label="Risk Estimation (Done)")
      output$consump_data<-renderDT(
        datatable(
         data_show2,options = list(lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
          editable = FALSE)  %>%   formatSignif(columns = c(5:6), digits = 2))
     }
       }
     }
   }
   )

}


 #-------quality----
 Module_quality_Ui <- function(id){
   ns <- NS(id)
   tabItem(tabName = "quality", 
           fluidPage(
             fluidRow(
               box(title = "Step 1. Chemical Selection", width =6, solidHeader = TRUE, status = "primary",
                   collapsible=TRUE, collapsed=FALSE,
                   selectInput(ns('groups'),"Group",choices=group_list,selected='OCPs'),
                   checkboxGroupInput(ns('chemicals'), 'Chemical',choices=OCP_list, selected=OCP_list,
                                      inline=TRUE)
                   
               ),
               
               
               
               
               box(title = "Step 2. Data quality in each literature", width = 6, solidHeader = TRUE, status = "primary",
                   collapsible=TRUE, collapsed=FALSE,
                   actionBttn(ns("data_shown"), label='GO!',color = "primary",style = "gradient",size='lg'),
                   br(),
                   br(),
                   downloadBttn(ns('data_shown_download'),label='Data Download',size='sm',color="success",style='pill')
               )
               
               
             ),
             
             fluidRow(uiOutput(ns("title_pollutant"))),
             fluidRow(DT::dataTableOutput(ns("liteature_data")))
             
           )
   )
 }
 
 Module_quality_Server <- function(input, output, session){
   
   observeEvent(input$groups,
                {
                  if (input$groups=='OCPs')
                  {
                    updateCheckboxGroupInput(session,'chemicals', 'Chemical',choices=OCP_list, 
                                             selected=OCP_list, inline=TRUE)
                    
                  } else if (input$groups=='Dioxins and PCBs')
                  {
                    updateCheckboxGroupInput(session,'chemicals','Chemical',choices=PCDD_list, selected=PCDD_list,
                                             inline=TRUE)
                  } else if (input$groups=='BFRs')
                  {
                    updateCheckboxGroupInput(session,'chemicals','Chemical',choices=BFR_list, selected=BFR_list,
                                             inline=TRUE)
                  } else if (input$groups=='PFASs')
                  {
                    updateCheckboxGroupInput(session,'chemicals','Chemical',choices=PFAS_list, selected=PFAS_list,
                                             inline=TRUE)
                  } else if (input$groups=='Other POPs')
                  {
                    updateCheckboxGroupInput(session,'chemicals','Chemical',choices=Others_list, selected=Others_list,
                                             inline=TRUE)
                  } 
                }
   )
   
   output$data_shown_download<-downloadHandler(filename = function(){
     paste("recent",gsub(":","-",Sys.time()), ".xlsx", sep="")
   },
   content=function(con)
   {file.copy(paste0(ind_code_path,'quality.xlsx'),con)
   })
   
   observeEvent(input$data_shown,
                {
                  
                  
                  data_all<-read.xlsx('./work/quality/data_quality.xlsx')
                  data_show<-subset(data_all, Chemical %in% input$chemicals)
                  
                  
                  if (nrow(data_show)>0)
                  { 
                    output$title_pollutant<-renderUI({mainPanel(h3("QA/QC information and sampling information for selected literature"))})
                    filetemp=paste0(ind_code_path,'quality.xlsx')
                    
                    
                    write.xlsx(data_show,filetemp)
                    output$liteature_data<-renderDT(
                      datatable(
                        data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                        editable = FALSE))
                    
                    
                  } else
                  {
                    showModal(modalDialog(
                      title = "Important message",
                      "No available data",
                      easyClose = TRUE))
                  }
                }
                
   )
 }
#-------recent update----
Module_update_Ui <- function(id){
  ns <- NS(id)
  tabItem(tabName = "update", 
          fluidPage(
            fluidRow(
              box(title = "Step 1. Chemical Selection", width =6, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  selectInput(ns('groups'),"Group",choices=group_list_recent,selected='OCPs'),
                  checkboxGroupInput(ns('chemicals'), 'Chemical',choices=OCP_list, selected=OCP_list,
                                     inline=TRUE)
                  
              ),
              
              
           
            
              box(title = "Step 2. Recent Literature", width = 6, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  actionBttn(ns("data_shown"), label='GO!',color = "primary",style = "gradient",size='lg'),
                  br(),
                  br(),
                  downloadBttn(ns('data_shown_download'),label='Data Download',size='sm',color="success",style='pill')
              )
              
              
            ),
            
            fluidRow(uiOutput(ns("title_pollutant"))),
            fluidRow(DT::dataTableOutput(ns("liteature_data")))
           
          )
  )
}

Module_update_Server <- function(input, output, session){

  observeEvent(input$groups,
               {
                 
                 if (input$groups=='OCPs')
                 {
                   updateCheckboxGroupInput(session,'chemicals', 'Chemical',choices=OCP_list, 
                                            selected=OCP_list, inline=TRUE)
                   
                 } else if (input$groups=='Dioxins and PCBs')
                 {
                   updateCheckboxGroupInput(session,'chemicals','Chemical',choices=PCDD_list, selected=PCDD_list,
                                            inline=TRUE)
                 } else if (input$groups=='BFRs')
                 {
                   updateCheckboxGroupInput(session,'chemicals','Chemical',choices=BFR_list, selected=BFR_list,
                                            inline=TRUE)
                 } else if (input$groups=='PFASs')
                 {
                   updateCheckboxGroupInput(session,'chemicals','Chemical',choices=PFAS_list, selected=PFAS_list,
                                            inline=TRUE)
                 } else if (input$groups=='Other POPs')
                 {
                   updateCheckboxGroupInput(session,'chemicals','Chemical',choices=Others_list, selected=Others_list,
                                            inline=TRUE)
                 } else if (input$groups=='Unclassified')
                 {
                   updateCheckboxGroupInput(session,'chemicals','Chemical',choices="Unclassified", selected="Unclassified",
                                            inline=TRUE)
                 }
               }
  )
  
  output$data_shown_download<-downloadHandler(filename = function(){
    paste("recent",gsub(":","-",Sys.time()), ".csv", sep="")
  },
  content=function(con)
  {file.copy(paste0(ind_code_path,'recent.xlsx'),con)
  })
  
  observeEvent(input$data_shown,
               {
                 
                 
                 data_all<-read.xlsx('./work/recent/recent.xlsx')
                 data_show<-subset(data_all, Chemical %in% input$chemicals)
                
                 
                 if (nrow(data_show)>0)
                 { 
                   output$title_pollutant<-renderUI({mainPanel(h3("Summary on recent liteature"))})
                   filetemp=paste0(ind_code_path,'recent.xlsx')
                 
                 colnames(data_show)[2]<-'Chemical'
                 write.xlsx(data_show,filetemp)
                 output$liteature_data<-renderDT(
                   datatable(
                     data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                     editable = FALSE))
                 
               
                 } else
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "No available data",
                     easyClose = TRUE))
                 }
               }
               
  )
}


#-------data download----
Module_download_literature_Ui<- function(id){
  ns <- NS(id) # Creates Namespace
  fluidPage(
    fluidRow(
      
      box(title = "Data download", width =10, solidHeader = TRUE, status = "primary",
          collapsible=TRUE, collapsed=FALSE,
          awesomeRadio(
            ns('type'),
            label='Data selection',
            choices=download_literature,
            selected =download_literature[1],
            inline = FALSE,
            status = "primary",
            checkbox = FALSE,
            width = NULL
          ),
          
          checkboxGroupInput(ns('groups'), 'Group',choices=group_list, selected=group_list,
                             inline=TRUE),
          
          checkboxGroupInput(ns('chemicals'), 'Chemical',choices=chemical_list, selected=chemical_list,
                             inline=TRUE),
          downloadBttn(ns('download'),label='Data Download',size='md',color="success",style='pill')
          
      )
    )
  )
}


Module_download_literature_Server <- function(input, output, session){
  
  observeEvent(input$type,
               {
                  if ((input$type==download_literature[1]))
                 {
                   updateCheckboxGroupInput(session,inputId='groups',label='Group',
                                            choices=group_list, selected=group_list,
                                            inline=TRUE
                   )
                   
                   updateCheckboxGroupInput(session,inputId='chemicals',label='Chemical',
                                            choices=chemical_list, selected=chemical_list,
                                            inline=TRUE
                   )
                   
                   # data_all<-read.xlsx('./work/literature/all.xlsx')
                   # data_show<-subset(data_all, Chemical %in% input$chemicals)
                   # write.xlsx(data_show,paste0(downloaddir,'literature/literature_information.xlsx'))
                 }  else if (input$type==download_literature[2])
                 {
                   updateCheckboxGroupInput(session,inputId='groups',label='Group',
                                            choices=group_list_recent, selected=group_list_recent,
                                            inline=TRUE
                                            )
                   updateCheckboxGroupInput(session,inputId='chemicals',label='Chemical',
                                            choices=chemical_list_recent, selected=chemical_list_recent,
                                            inline=TRUE
                   )
                   # data_all<-read.xlsx('./work/recent/recent.xlsx')
                   # data_show<-subset(data_all, Chemical %in% input$chemicals)
                   # write.xlsx(data_show,paste0(downloaddir,'literature/literature_information.xlsx'))
                 } else if ((input$type==download_literature[3]))
                 {
                   updateCheckboxGroupInput(session,inputId='groups',label='Group',
                                            choices=group_list, selected=group_list,
                                            inline=TRUE
                   )
                   
                   updateCheckboxGroupInput(session,inputId='chemicals',label='Chemical',
                                            choices=chemical_list, selected=chemical_list,
                                            inline=TRUE
                   )
                   
                   # data_all<-read.xlsx('./work/quality/data_quality.xlsx')
                   # data_show<-subset(data_all, Chemical %in% input$chemicals)
                   # write.xlsx(data_show,paste0(downloaddir,'literature/literature_information.xlsx'))
                 }
               }
  )
  
  observeEvent(input$groups,
               {
                 if (is.null(input$groups))
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "Pls select at least one option for group",
                     easyClose = TRUE))
                   
                   updateCheckboxGroupInput(session,inputId='chemicals',label='Chemical',
                                            choices=character(0), selected=NULL,
                                            inline=TRUE
                   )
                   # file.copy(from='./work/download/empty.xlsx',
                   #           to=paste0(downloaddir,'literature/literature_information.xlsx'),overwrite = TRUE)
                 }      else 
                 {
                   
                   data_group<-read.xlsx('./work/download/group_info.xlsx')
                   data_group_sel<-subset(data_group, Group %in% input$groups)
                   updateCheckboxGroupInput(session,inputId='chemicals',label='Chemical',
                                            choices=data_group_sel$Chemical, selected=data_group_sel$Chemical,
                                            inline=TRUE
                   )
                   
                 # if ((input$type==download_literature[1]))
                 # {
                 #   
                 #   
                 #   data_all<-read.xlsx('./work/literature/all.xlsx')
                 #   data_show<-subset(data_all, Chemical %in% input$chemicals)
                 #   write.xlsx(data_show,paste0(downloaddir,'literature/literature_information.xlsx'))
                 # }  else if (input$type==download_literature[2])
                 # {
                 # 
                 #   data_all<-read.xlsx('./work/recent/recent.xlsx')
                 #   data_show<-subset(data_all, Chemical %in% input$chemicals)
                 #   write.xlsx(data_show,paste0(downloaddir,'literature/literature_information.xlsx'))
                 # } else if ((input$type==download_literature[3]))
                 # {
                 #  
                 # 
                 #   data_all<-read.xlsx('./work/quality/data_quality.xlsx')
                 #   data_show<-subset(data_all, Chemical %in% input$chemicals)
                 #   write.xlsx(data_show,paste0(downloaddir,'literature/literature_information.xlsx'))
                 # }
                 }
               },ignoreNULL = FALSE
  )
  
  observeEvent(input$chemicals,
               {
                 if (is.null(input$chemicals))
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "Pls select at least one chemical",
                     easyClose = TRUE))
                   
                   # file.copy(from='./work/download/empty.xlsx',
                   #           to=paste0(downloaddir,'literature/literature_information.xlsx'),overwrite = TRUE)
                   
                 }      else 
                 {
                  
                   
                   # if ((input$type==download_literature[1]))
                   # {
                   #   
                   #   
                   #   data_all<-read.xlsx('./work/literature/all.xlsx')
                   #   data_show<-subset(data_all, Chemical %in% input$chemicals)
                   #   
                   #   if (nrow(data_show)>0)
                   #   {
                   #   write.xlsx(data_show,paste0(downloaddir,'literature/literature_information.xlsx'))} else
                   #   {
                   #     file.copy(from='./work/download/empty.xlsx',
                   #               to=paste0(downloaddir,'literature/literature_information.xlsx'),overwrite = TRUE)
                   #   }
                   # }  else if (input$type==download_literature[2])
                   # {
                   #   
                   #   data_all<-read.xlsx('./work/recent/recent.xlsx')
                   #   data_show<-subset(data_all, Chemical %in% input$chemicals)
                   #   if (nrow(data_show)>0)
                   #   {
                   #     write.xlsx(data_show,paste0(downloaddir,'literature/literature_information.xlsx'))} else
                   #     {
                   #       file.copy(from='./work/download/empty.xlsx',
                   #                 to=paste0(downloaddir,'literature/literature_information.xlsx'),overwrite = TRUE)
                   #     }
                   #   
                   # } else if ((input$type==download_literature[3]))
                   # {
                   #   
                   #   
                   #   data_all<-read.xlsx('./work/quality/data_quality.xlsx')
                   #   data_show<-subset(data_all, Chemical %in% input$chemicals)
                   #   
                   #   if (nrow(data_show)>0)
                   #   {
                   #     write.xlsx(data_show,paste0(downloaddir,'literature/literature_information.xlsx'))} else
                   #     {
                   #       file.copy(from='./work/download/empty.xlsx',
                   #                 to=paste0(downloaddir,'literature/literature_information.xlsx'),overwrite = TRUE)
                   #     }
                   # }
                 }
               },ignoreNULL = FALSE
  )
  
  output$download<-downloadHandler(filename = function(){
    paste("literature information",gsub(":","-",Sys.time()), ".xlsx", sep="")
  },
  content=function(con)
  {
    if (is.null(input$chemicals))
    {
      file.copy(from='./work/download/empty.xlsx',
                to=paste0(downloaddir,'literature/literature_information.xlsx'),overwrite = TRUE)
    } else
    {
     if (input$type==download_literature[1])
     {
       data_all<-read.xlsx('./work/literature/all.xlsx')
     
     } else if (input$type==download_literature[2])
     {
       data_all<-read.xlsx('./work/recent/recent.xlsx')
      
     } else if ((input$type==download_literature[3]))
      {
        data_all<-read.xlsx('./work/quality/data_quality.xlsx')
       
     }
      
      data_show<-subset(data_all, Chemical %in% input$chemicals)
      
      if (nrow(data_show)>0)
      {
        write.xlsx(data_show,paste0(downloaddir,'literature/literature_information.xlsx'))} else
        {
          file.copy(from='./work/download/empty.xlsx',
                    to=paste0(downloaddir,'literature/literature_information.xlsx'),overwrite = TRUE)
        }
    }
    
    file.copy(paste0(downloaddir,'literature/literature_information.xlsx'),con)
  })
  
 
}

Module_download_data_Ui<- function(id){
  ns <- NS(id) # Creates Namespace
  fluidPage(
    fluidRow(
      
      box(title = "Data download", width =10, solidHeader = TRUE, status = "primary",
          collapsible=TRUE, collapsed=FALSE,
          awesomeRadio(
            ns('type'),
            label='Data selection',
            choices=download_data_list,
            selected =download_data_list[1],
            inline = FALSE,
            status = "primary",
            checkbox = FALSE,
            width = NULL
          ),
          
          checkboxGroupInput(ns('groups'), 'Group',choices=group_list, selected=group_list,
                             inline=TRUE),
          
          checkboxGroupInput(ns('chemicals'), 'Chemical',choices=chemical_list, selected=chemical_list,
                             inline=TRUE),
          downloadBttn(ns('download'),label='Data Download',size='md',color="success",style='pill')
          
      )
    )
  )
}

Module_download_data_Server <- function(input, output, session){

  
  observeEvent(input$groups,
               {
                 if (is.null(input$groups))
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "Pls select at least one option for group",
                     easyClose = TRUE))
                   updateCheckboxGroupInput(session,inputId='chemicals',label='Chemical',
                                            choices=character(0), selected=NULL,
                                            inline=TRUE
                   )
                   
                 } else
                 {
                   
                   data_group<-read.xlsx('./work/download/group_info.xlsx')
                   data_group_sel<-subset(data_group, Group %in% input$groups)
                   updateCheckboxGroupInput(session,inputId='chemicals',label='Chemical',
                                            choices=data_group_sel$Chemical, selected=data_group_sel$Chemical,
                                            inline=TRUE
                   )
                 }
                
               },ignoreNULL = FALSE
  )
  
  observeEvent(input$chemicals,
               {
                 if (is.null(input$chemicals))
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "Pls select at least one chemical",
                     easyClose = TRUE))
                   
                 }      
               },ignoreNULL = FALSE
  )
  
  output$download<-downloadHandler(filename = function(){
    paste("download",gsub(":","-",Sys.time()), ".zip", sep="")
  },
  content=function(con)
  {
   file.remove(dir(paste0(downloaddir,'data/'),full.names = TRUE))
    if (file.exists(downloaddirplus))
    {
      file.remove(downloaddirplus) 
    }
    
   if (is.null(input$chemicals))
   {

     file.copy(from='./work/download/empty.xlsx',
               to=paste0(downloaddir,'data/data_download.xlsx'),overwrite = TRUE)

   } else
   {
     if (input$type==download_data_list[1])
     {
     targetdir<-'./work/database/'

     for (filenameloop in input$chemicals)
     {
       if (file.exists(paste0(targetdir,filenameloop,'.xlsx')))

    {   file.copy(from=paste0(targetdir,filenameloop,'.xlsx'),
                 to=paste0(downloaddir,'data/',filenameloop,'.xlsx'),overwrite = TRUE)
       } else {
         file.copy(from='./work/download/empty.xlsx',
                   to=paste0(downloaddir,'data/',filenameloop,'.xlsx'),overwrite = TRUE)
       }
     }

     } else
     {
       targetdir<-'./work/analysis/PoPs/'

       for (filenameloop in input$chemicals)
       {
         if (file.exists(paste0(targetdir,filenameloop,'_analysis.xlsx')))

         {   file.copy(from=paste0(targetdir,filenameloop,'_analysis.xlsx'),
                       to=paste0(downloaddir,'data/',filenameloop,'.xlsx'),overwrite = TRUE)
         } else {
           file.copy(from='./work/download/empty.xlsx',
                     to=paste0(downloaddir,'data/',filenameloop,'.xlsx'),overwrite = TRUE)
         }
       }
     }



   }
    
    # zipcode<-paste0('cd /homes/cctdb/shiny/pops/temp/',seedrnd,'/download/ && zip -q -r ../download.zip data/' )
    # 
    # system(zipcode)
    
  #  file.copy(downloaddirplus,con)
    
  })
  
}

Module_download_supporting_Ui<- function(id){
  ns <- NS(id) # Creates Namespace
  fluidPage(
    fluidRow(
      
      box(title = "Document download", width =10, solidHeader = TRUE, status = "primary",
          collapsible=TRUE, collapsed=FALSE,
          awesomeRadio(
            ns('type'),
            label='Document selection',
            choices=download_supporting,
            selected =download_supporting[1],
            inline = FALSE,
            status = "primary",
            checkbox = FALSE,
            width = NULL
          ),
     
          
          downloadBttn(ns('download'),label='Document Download',size='md',color="success",style='pill')
          
      )
    )
  )
}

Module_download_supporting_Server <- function(input, output, session){
  
  output$download<-downloadHandler(filename = function(){
    
    if (input$type==download_supporting[1])
    {
    paste("manual.mp4")
      }  else if (input$type==download_supporting[2])
    {
      paste("code.zip")
    } else if (input$type==download_supporting[3])
    {
      paste("abbreviations.pdf")
    }
    
  },
  content=function(con)
  {
    if (input$type==download_supporting[1])
    {
    file.copy(paste0('./work/download/manual.mp4'),con) 
       }    else if (input$type==download_supporting[2])
    {
      file.copy(paste0('./work/download/code.zip'),con)
    } else if (input$type==download_supporting[3])
    {
      file.copy(paste0('./work/download/abbreviations.pdf'),con)
    }
  })
  
}


Module_download_Ui<-function(id){
  ns <- NS(id)
  tabItem(tabName = "download", tabsetPanel(tabPanel("Literature information",Module_download_literature_Ui(ns("literature"))),
                                              tabPanel("Expsoure data",Module_download_data_Ui(ns("data"))),
                                              tabPanel("Supporting documents",Module_download_supporting_Ui(ns("supporting")))
                                            ))
}

Module_download_Server <- function(input, output, session){
  callModule(Module_download_literature_Server,"literature")
  callModule(Module_download_data_Server,"data")
  callModule(Module_download_supporting_Server,"supporting")
}
#-----main framework-------------
ui <- dashboardPage(
  dashboardHeader(),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Introduction", tabName="introduction"),
      menuItem("Literature list", tabName = "lit"),
      menuItem("Exposure database", tabName = "database"),
      menuItem("Data analysis", tabName = "analysis"),
      menuItem("Human health risk assessment", tabName = "hhra"),
      menuItem("Data quality", tabName = "quality"),
      menuItem("Recent literature", tabName = "update"),
      menuItem("Data download", tabName = "download")
    )
  ),
  dashboardBody(
    tabItems(
      Module_introduction_Ui("introduction"),
      Module_lit_Ui("lit"),
      Module_database_Ui("database"),
      Module_analysis_Ui("analysis"),
      Module_hhra_Ui("hhra"),
      Module_quality_Ui("quality"),
      Module_update_Ui("update"),
      Module_download_Ui("download")
    )))

server <- function(input,output,server){
  callModule(Module_introduction_Server,"introduction")
  callModule(Module_lit_Server,"lit")
  callModule(Module_database_Server,"database")
  callModule(Module_analysis_Server,"analysis")
  callModule(Module_hhra_Server,"hhra")
  callModule(Module_quality_Server,"quality")
  callModule(Module_update_Server,"update")
  callModule(Module_download_Server,"download")
}

shinyApp(ui,server)