pathset<-getwd() 

list.of.packages<-c("shiny","shinydashboard","DT","shinyalert","readxl","readr","openxlsx","shinyWidgets",
                    "ggplot2","shinyBS","fitdistrplus","stringr","mapdata","maptools","ggplot2","plyr","mapproj")

new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
for(name in list.of.packages){
  #
  require(name,character.only = TRUE)
}


ind_code_path<<-paste0(pathset,"/temp/",as.character(sample(1:1000000,size=1)),"_")
file.copy(from='./work/literature/download_temp.csv',
          to=paste0(ind_code_path,'lit_summary.csv'),overwrite = TRUE)

file.copy(from='./work/literature/download_temp.csv',
          to=paste0(ind_code_path,'exposure_database.csv'),overwrite = TRUE)

file.copy(from='./work/literature/download_temp.csv',
          to=paste0(ind_code_path,'data_analysis.csv'),overwrite = TRUE)
file.copy(from='./work/literature/download_temp.csv',
          to=paste0(ind_code_path,'recent.csv'),overwrite = TRUE)

pathway_list<-c("air","dust","soil","sediment","water","food","blood","breast milk","biological","others")
pathway_hhra<-c("air","soil","water","food")
pathway_hhra_unit<-c("ng/m3","ng/kg","ng/L","ng/kg")
pathway_list_analysis<-c("air","dust","soil","sediment","water","food","blood","breast milk")

air_unit_list<-c('ng/m3')
dust_unit_list<-c('ng/kg',"ng/kg dw")
soil_unit_list<-c('ng/kg',"ng/kg dw")
sediment_unit_list<-c('ng/kg',"ng/kg dw")
food_unit_list<-c('ng/kg',"ng/kg ww","ng/kg dw")
water_unit_list<-c('ng/L')
blood_unit_list<-c('ng/kg',"ng/kg lw","ng/L")
breast_unit_list<-c('ng/kg',"ng/kg lw","ng/L")

group_list<-c('OCPs',"Dioxins and PCBs","BFRs","PFASs","Other POPs")
OCP_list<-c('DDT','Aldrin', 'Chlordane', 'Chlordecone',  'Dicofol', 'Dieldrin','Endrin',
             'Endosulfan', 'Hexachlorobenzene', 'Hexachlorocyclohexane', 'Heptachlor',
            'Mirex', 'Pentachlorobenzene', 'Pentachlorophenol','Toxaphene')

PCDD_list<-c('PCDD&Fs',"PBDD&Fs","PCBs")
PFAS_list<-c('PFOA',"PFOS")
BFR_list<-c('PBDEs',"Hexabromocyclododecane","Hexabromobiphenyl")
Others_list<-c("SCCPs", "Hexachlorobutadiene","Polychlorinated naphthalenes")
chemical_list<-c('Aldrin',"Chlordane","Chlordecone","SCCPs","DDT",'Dicofol',
                 "Dieldrin",'PCDDs',"PCDFs","Endrin","Endosulfan","HBB","Hexabromocyclododecane","HCB",
                 "HCBD","HCH","Heptachlor","Mirex","PCP","PCNs","PCBs",
                 "Pentachlorobenzene","PFOA","Toxaphene","PFOS")
main_code_path<<-paste0(pathset,"/work/")
supp_code_path<-paste0(pathset,'/work/code/pops_project_support.R')
source(supp_code_path,encoding = "utf-8")

#---------#Introduction--------
Module_introduction_Ui<-function(id){
  ns <- NS(id)
 # fluidPage(theme = "custom.css")
  tabItem(tabName = "introduction",
          fluidPage(
            uiOutput(ns("introduction")
            )
            
          )
          
  )
}

Module_introduction_Server <- function(input, output, session) {
  
  output$introduction<-renderUI({fluidPage(h2("PoPs_EXPs Project",align = "center",style = "font-family: 'Baskerville'; font-size: 380%; font-weight: 300"),
                                           h5("PoPs_EXPs project aims to establish an online database on the exposure to 
                                              persistent organic pollutants (PoPs) in China. This project includes five tools: 1) Liteature summary, to summarize all available liteature, and the data extracted 
                                              from available liteature are intergated in the 2nd tool, termed as 2) Exposure database; 3) Data analysis, attempts to perform the spatiotemporal trend analysis of PoPs exposure in China; 
                                              4) Human health risk assessment, to conduct basic risk assessment for PoPs; 
                                              5) Recent literature, to retrieve recent reports with respect to  PoPs exposure in China, 
                                              while the data from recent reports have not yet been extracted.",style ="font-family: 'Helvetica Neue',Helvetica;font-weight: 200;
                                              line-height: 2.1; font-size: 150%"),
                                           br(),
                                           h5("Update date:  12-August-2020",style = "font-family: 'Helvetica Neue',Helvetica; font-weight: 200;
                                              line-height: 2.1; font-size: 150%"),    
                                           
                                           
                                           h5("Contact: dongzm@buaa.edu.cn. More detailed information pls refer to", a("POPs-EXPs on Github",href="https://github.com/POPs-EXPs/beta-version",color='red'),style = "font-family: 'Helvetica Neue',Helvetica; font-weight: 200;
                                              line-height: 2.1; font-size: 130%")   )})
  
  }
#-------liteature------------

#Ui/Server for exposure
Module_lit_Ui<-function(id){
  ns <- NS(id)
  tabItem(tabName = "lit", 
          fluidPage(
            fluidRow(
              box(title = "Step 1. Chemical Selection", width =4, solidHeader = TRUE,  
                  status = "primary",collapsible=TRUE, collapsed=FALSE,
               selectInput(ns('groups'),"Groups",choices=group_list,selected='OCPs'),
                checkboxGroupInput(ns('chemicals'), 'Chemicals',choices=OCP_list, selected=OCP_list,
                                  inline=TRUE)
                  
              ),
              
              box(title = "Step 2. Pathway Identification", width = 4, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  checkboxGroupInput(ns('pathway'), label=NULL, choices=pathway_list, selected=pathway_list,
                                     inline=TRUE)

              ),
              
              box(title = "Step 3. Literature Searach", width = 3, solidHeader = TRUE, collapsible=TRUE, collapsed=FALSE,
                  status = "primary",
                  actionBttn(ns("data_shown"), label='GO!',color = "primary",style = "gradient",size='lg'),
             #    actionButton(ns("data_shown"), 'GO!',style="color: #FFFFFF; background-color: #36648B; border-color: #36648B"),
                  br(),
                  br(),
                 
             downloadBttn(ns('data_shown_download'),label='Data Download',size='sm',color="success",style='pill')
          #    downloadButton(ns('data_shown_download'),
           #                       "Download",style="color: #FFFFFF; background-color: #339900; border-color: #339900")
               )
             

            ),
            
             fluidRow(uiOutput(ns("title_pollutant"))),
             fluidRow(DT::dataTableOutput(ns("liteature_data"))),
            br(),
          fluidRow(uiOutput(ns("year_title"))),
          imageOutput((ns("year"))),
          fluidRow(uiOutput(ns("journal_title"))),
            imageOutput((ns("journal")))
            )
          )
}

Module_lit_Server<- function(input, output, session){
  
  observeEvent(input$groups,
               {
                 
                 if (input$groups=='OCPs')
                 {
                   updateCheckboxGroupInput(session,'chemicals', 'Chemicals',choices=OCP_list, 
                                            selected=OCP_list, inline=TRUE)
                 
                   } else if (input$groups=='Dioxins and PCBs')
                 {
                   updateCheckboxGroupInput(session,'chemicals','Chemicals',choices=PCDD_list, selected=PCDD_list,
                                           inline=TRUE)
                 } else if (input$groups=='BFRs')
                 {
                   updateCheckboxGroupInput(session,'chemicals','Chemicals',choices=BFR_list, selected=BFR_list,
                                           inline=TRUE)
                 } else if (input$groups=='PFASs')
                 {
                   updateCheckboxGroupInput(session,'chemicals','Chemicals',choices=PFAS_list, selected=PFAS_list,
                                            inline=TRUE)
                 } else if (input$groups=='Other POPs')
                 {
                   updateCheckboxGroupInput(session,'chemicals','Chemicals',choices=Others_list, selected=Others_list,
                                           inline=TRUE)
                 }
               }
)

 output$data_shown_download<-downloadHandler(filename = function(){
    paste("lit_summary",gsub(":","-",Sys.time()), ".csv", sep="")
  },
  content=function(con)
  {file.copy(paste0(ind_code_path,'lit_summary.csv'),con)
  })

  observeEvent(input$data_shown,
               {
                 output$title_pollutant<-renderUI({mainPanel(h3("Available liteature on exposure data for selected PoPs (updated to 2020-05-31)")  )})
                 data_all<-read.xlsx('./work/literature/all.xlsx')
                 data_show<-subset(data_all, sub_group %in% input$chemicals & pathway %in% input$pathway)
                 data_show1<-subset(data_all,sub_group %in% input$chemicals & article_type=='Review' )
                 data_show<-rbind(data_show,data_show1)
                 filetemp=paste0(ind_code_path,'lit_summary.csv')
                 write.csv(data_show,filetemp,row.names = FALSE)
                 output$liteature_data<-renderDT(
                   datatable(
                     data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                     editable = FALSE))
                 
                 if (nrow(data_show)>0)
                 {
                   data_temp<-data_show[,c(4:ncol(data_show))]
                   result<-data_temp[!duplicated(data_temp$PMID),]
                  # result<-unique(data_temp$publication)
                 
                 output$year_title<-renderUI({mainPanel(
                   h3("The number of publications in each year")
                 )})
                 output$journal_title<-renderUI({mainPanel(
                   h3("The journal distribution for all publications")
                 )})
                 
                 
                 year_list_all<-as.double(as.character(result$year))
                 year_list<-sort(unique(as.double(as.character(result$year))))
                 year_number<-rep(0,length(year_list))
                 
                 for (i in 1:length(year_list))
                 {
                   year_number[i]<-length(which(year_list_all==year_list[i]))
                 }
                 
                 journal_list<-((unique(result$journal)))
                 journal_number<-rep(0,length(journal_list))
                 for (i in 1:length(journal_list))
                 {
                   journal_number[i]<-length(which(result$journal==journal_list[i]))
                 }
                 outfile <- paste0(ind_code_path,'_publication.png')
                 if (file.exists(paste0(ind_code_path,'_publication.png')))
                 {
                   file.remove(paste0(ind_code_path,'_publication.png'))
                 }
                 png(outfile, width =640, height = 360)
                 gp1<-plot(year_list,year_number,type='b',
                           xlab = "Year", ylab="Number")
                 
                 dev.off()
                 output$year<-renderImage({
                   filename <- normalizePath(file.path(paste0(ind_code_path,'_publication.png'))) #download, need to refine
                   list(src = filename,width=640,height=360)
                 },deleteFile = FALSE
                 
                 )
                 
                 journal_label=data.frame(number=journal_number,name=journal_list)
                 order_tmp<-order(journal_label$number,decreasing=TRUE)
                 journal_label<-journal_label[order_tmp,]
                 n=5
                 if (nrow(journal_label)>n+1)
                 {
                   journal_label1<-journal_label[1:(n+1),]
                   journal_label2<-journal_label[-c(1:(n)),]
                   other_num<-sum(journal_label2$number) 
                   journal_label1[n+1,1]<-other_num
                   journal_label1$name<-as.character(journal_label1$name)
                   journal_label1[n+1,2]<-'Others'
                 } else
                 {
                   journal_label1<-journal_label
                   
                   journal_label1$name<-as.character(journal_label1$name)
                   
                 }
                 
                 for ( i in 1:nrow(journal_label1))
                 {
                   journal_label1$label[i]<-paste0(journal_label1$name[i],"(",journal_label1$number[i],")")
                 }
                 
                 outfile <- paste0(ind_code_path,'_journal.png')
                 if (file.exists(paste0(ind_code_path,'_journal.png')))
                 {
                   file.remove(paste0(ind_code_path,'_journal.png'))
                 }
                 png(outfile, width =640, height = 360)
                 gp1<-pie(journal_label1$number,label=journal_label1$label,
                          main="Journals",col= terrain.colors (length(journal_label1$number)))
                 
                 dev.off()
                 output$journal<-renderImage({
                   filename <- normalizePath(file.path(paste0(ind_code_path,'_journal.png'))) #download, need to refine
                   list(src = filename,width=640,height=360)
                 },deleteFile = FALSE
                 
                 )
                 }
                 
               } 
              
  )

}

#-------PoPs database-------------

Module_database_Ui<-function(id){
  ns <- NS(id)
  tabItem(tabName = "database", 
          fluidPage(
            fluidRow(
              box(title = "Step 1. Chemical Selection", width =4, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  selectInput(ns('groups'),"Groups",choices=group_list,selected='OCPs'),
                  selectInput(ns('chemicals'), 'Chemicals',choices=OCP_list, selected=OCP_list[1]
                                     )
                  
              ),
              
              box(title = "Step 2. Pathway Identification", width = 4, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  checkboxGroupInput(ns('pathway'), label=NULL, choices=pathway_list, selected=pathway_list,
                                     inline=TRUE)
                  
              ),
              
              box(title = "Step 3. Data Display", width = 3, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                #  actionButton(ns("data_shown"), 'Data Shown',
                 #              width=120,style="color: #FFFFFF; background-color: #339900; border-color: #339900"),
                actionBttn(ns("data_shown"), label='GO!',color = "primary",style = "gradient",size='lg'),  
                
                br(),
                  br(),
                downloadBttn(ns('data_shown_download'),label='Data Download',size='sm',color="success",style='pill')
                 # downloadButton(ns('data_shown_download'),
                  #               "Download",style="color: #FFFFFF; background-color: #339900; border-color: #339900")
              )
              
              
            ),
            
           fluidRow(uiOutput(ns("title_pollutant"))),
            fluidRow(DT::dataTableOutput(ns("liteature_data")))
            
          )
  )
}

Module_database_Server<-function(input, output, session) {

  
  observeEvent(input$groups,
               {
                 
                 if (input$groups=='OCPs')
                 {
                   updateSelectInput(session,'chemicals', 'Chemicals',choices=OCP_list, 
                                            selected=OCP_list[1])
                   
                 } else if (input$groups=='Dioxins and PCBs')
                 {
                   updateSelectInput(session,'chemicals','Chemicals',choices=PCDD_list, selected=PCDD_list[1])
                 } else if (input$groups=='BFRs')
                 {
                   updateSelectInput(session,'chemicals','Chemicals',choices=BFR_list, selected=BFR_list[1])
                 } else if (input$groups=='PFASs')
                 {
                   updateSelectInput(session,'chemicals','Chemicals',choices=PFAS_list, selected=PFAS_list[1])
                 } else if (input$groups=='Other POPs')
                 {
                   updateSelectInput(session,'chemicals','Chemicals',choices=Others_list, selected=Others_list[1])
                 }
               }
  )
  
  output$data_shown_download<-downloadHandler(filename = function(){
    paste("exposure_database",gsub(":","-",Sys.time()), ".csv", sep="")
  },
  content=function(con)
  {file.copy(paste0(ind_code_path,'exposure_database.csv'),con)
  })
  
  observeEvent(input$data_shown,
               {
                 output$title_pollutant<-renderUI({mainPanel(h3("Exposure data for selected PoPs(updated to 2020-05-31)")  )})
           file_temp_name<-paste0('./work/database/',input$chemicals,'.xlsx')
           if (!file.exists(file_temp_name))
           {
             
             showModal(modalDialog(
               title = "Important message",
               "No available data",
               easyClose = TRUE))
           } else
           {
                 data_all<-read.xlsx(file_temp_name)
                 data_show<-subset(data_all, Pathway %in% input$pathway)
                 # data_show<-data_all
                 filetemp=paste0(ind_code_path,'exposure_database.csv')
                 write.csv(data_show,filetemp,row.names = FALSE)
                 output$liteature_data<-renderDT(
                   datatable(
                     data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                     editable = FALSE)  %>%   formatSignif(columns = c(14:19), digits = 3))
                 
               } 
               
               }
  )
  
}

#------------temporal and spatial trend------------
Module_analysis_Ui <- function(id){
  ns <- NS(id)
  tabItem(tabName = "analysis",
          fluidPage(
            fluidRow(
              box(title = "Step 1. Data Display", width =3, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  selectInput(ns('groups'),"Groups",choices=group_list,selected='OCPs'),
                  selectInput(ns('chemicals'), 'Chemicals',choices=OCP_list, selected=OCP_list[1]
                  ),
                  selectInput(ns('pathway'), label="Pathway", choices=pathway_list_analysis, selected=pathway_list_analysis[1]),
              #    actionBttn(ns("data_shown"), label='Data Display',color = "primary",style = "gradient",size='sm'),  
                  # actionButton(ns("data_shown"), label="Data Refresh (No)",
                  #              style="color: #000000; background-color: #4F94CD; border-color: #4F94CD"),
                  #              
              actionBttn(ns("data_shown"), label='Data Update?',color = "primary",style = "gradient",size='md'),
                  br(),
                  br(),
                  
                  downloadBttn(ns('data_shown_download'),label='Data Download',size='sm',color="success",style='pill')
                 
                  
                
              ),
              
              box(title = "Step 2. Data Filter", width = 3, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  
                
                  selectInput(ns('chem_filter'), label='Chemical filter for further analysis',choices=c('all'), selected='all'),
                  selectInput(ns('unit'), label='Unit filter for further analysis',choices=c('ng/m3',"ng/kg","ng/L"), selected='ng/kg'),
                  # actionButton(ns("filter"), label="Data Filt (No)",
                  #              style="color: #000000; background-color: #4F94CD; border-color: #4F94CD")
                  actionBttn(ns("filter"), label='Data Filt(Not done)',color = "primary",style = "gradient",size='md')
                   ),
              
              box(title = "Step 3. Temporal Trend", width = 3, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  sliderInput(ns("sample_year_temp"),label="Sample Years",min=1980, max=2025, value=c(2000,2020)),
                  
                  checkboxGroupInput(ns("location_temp"), label="Province",choices=c('National'), selected=c('National')),
                 
                  
                  actionBttn(ns("temporal"), label='Temporal Analysis',color = "primary",style = "jelly",size='md')
                #   actionButton(ns("temporal"), label="Temporal Analysis",
                 #              width=130,style="color: #FFFFFF; background-color: #339900; border-color: #339900")
               
                  

              ),
              
              
              box(title = "Step 4. Spatial Trend", width = 3, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  sliderInput(ns("sample_year_spat"),label="Sample Years",min=1980, max=2025, value=c(2000,2020)),
                  
                  checkboxGroupInput(ns("location_spat"), label="Province",choices=c('National'), selected=c('National')),
                  
                  
                  actionBttn(ns("spatial"), label='Spatial Analysis',color = "primary",style = "jelly",size='md')
                 
                  
              )
              
            ),
            fluidRow(
              splitLayout(cellWidths = c("50%", "50%"),
                          plotOutput(ns("plot2")),
                          plotOutput(ns("plot3")))
            ),
           
            fluidRow(uiOutput(ns("title_pollutant"))),

            
            fluidRow(DT::dataTableOutput(ns("liteature_data")))
            
          
            
          )    
  )
}

Module_analysis_Server <- function(input, output, session){

 
  
  
  observeEvent(input$groups,
               {
                 updateActionButton(session,inputId="data_shown",label="Data Refresh (Done)")
                 updateActionButton(session,inputId="filter",label="Data Filt (Done)")
                 
                 if (input$groups=='OCPs')
                 {
                   updateSelectInput(session,'chemicals', 'Chemicals',choices=OCP_list, 
                                     selected=OCP_list[1])
                   
                 } else if (input$groups=='Dioxins and PCBs')
                 {
                   updateSelectInput(session,'chemicals','Chemicals',choices=PCDD_list, selected=PCDD_list[1])
                 } else if (input$groups=='BFRs')
                 {
                   updateSelectInput(session,'chemicals','Chemicals',choices=BFR_list, selected=BFR_list[1])
                 } else if (input$groups=='PFASs')
                 {
                   updateSelectInput(session,'chemicals','Chemicals',choices=PFAS_list, selected=PFAS_list[1])
                 } else if (input$groups=='Other POPs')
                 {
                   updateSelectInput(session,'chemicals','Chemicals',choices=Others_list, selected=Others_list[1])
                 }
               }
  )
  
  output$data_shown_download<-downloadHandler(filename = function(){
    paste("data_analysis",gsub(":","-",Sys.time()), ".csv", sep="")
  },
  content=function(con)
  {file.copy(paste0(ind_code_path,'data_analysis.csv'),con)
  })
  
  observeEvent(input$filter,
               {
                 file_temp_name<-paste0('./work/analysis/PoPs/',input$chemicals,'_analysis.xlsx')
                 
                 if (!file.exists(file_temp_name))
                 {
                   
                   showModal(modalDialog(
                     title = "Important message",
                     "No available data",
                     easyClose = TRUE))
                 } else {
                   data_all<-read.xlsx(file_temp_name)
                   
                   data_show<-subset(data_all, Pathway %in% input$pathway)
                 
                 if (nrow(data_show)==0)
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "Pls display/update the data prior to further analysis",
                     easyClose = TRUE))
                 } else
               {
                 if (input$chem_filter!="all")
                 {data_show<-subset(data_show, Unit %in% input$unit & chemicals %in% input$chem_filter)
                 } else 
                 {
            data_show<-subset(data_show,  Unit %in% input$unit)
                  
                   }
                 
                 
               if (nrow(data_show)==0)
               {
                 showModal(modalDialog(
                   title = "Important message",
                   "Pls display/update the data prior to further analysis",
                   easyClose = TRUE))
               } else {
                 updateActionButton(session,inputId="filter",label="Data Filt (Done)")
                 locationid_temp<-sort(unique(data_show$Province))
                
                 locationid<-sort(locationid_temp[which(locationid_temp!='Not specified')])
                 updateCheckboxGroupInput(session,"location_spat",label="Province",
                                          choices=locationid,selected=locationid,
                                          inline=TRUE)
                 
                 
                 updateCheckboxGroupInput(session,"location_temp",label="Province",
                                          choices=locationid_temp,selected=locationid_temp,
                                          inline=TRUE)
                 
                 yearid1<-unique(data_show$Year)
                 yearid<-as.double(unique(str_sub(yearid1,start=1,end=4)))
                 
                 updateSliderInput(session,inputId ="sample_year_temp",label="Sample Years",
                                   min=min(yearid,na.rm=TRUE), step=1,max=max(yearid,na.rm=TRUE), value=c(min(yearid,na.rm=TRUE),max(yearid,na.rm=TRUE)))
                 
                 updateSliderInput(session,inputId ="sample_year_spat",label="Sample Years",
                                   min=min(yearid,na.rm=TRUE), step=1,max=max(yearid,na.rm=TRUE), value=c(min(yearid,na.rm=TRUE),max(yearid,na.rm=TRUE)))
                 
                 output$liteature_data<-renderDT(
                   datatable(
                     data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                     editable = FALSE)  %>%   formatSignif(columns = c(14:19), digits = 3))  
               }
               }
               
               }
               }
               )
 
  observeEvent(input$temporal,
               {
                 file_temp_name<-paste0('./work/analysis/PoPs/',input$chemicals,'_analysis.xlsx')
                
                 if (!file.exists(file_temp_name))
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "No available data",
                     easyClose = TRUE))
                   
                 
                 } else
                 {
                   data_all<-read.xlsx(file_temp_name)
                   
                   if (input$chem_filter!="all")
                    {data_show1<-subset(data_all, Pathway %in% input$pathway & Unit %in% input$unit & chemicals %in% input$chem_filter)
                   } else 
                   {
                     data_show1<-subset(data_all, Pathway %in% input$pathway & Unit %in% input$unit)
                   }
                   
                   if (nrow(data_show1)==0)
                   {
                     showModal(modalDialog(
                       title = "Important message",
                       "No available data",
                       easyClose = TRUE))
                    
                   } else
                   {
                   
                   data_show1$year_temp<-as.double(str_sub(data_show1$Year,start=1,end=4))
                   
                   data_show<-subset(data_show1, Province %in% input$location_temp & 
                                       year_temp>(as.double(input$sample_year_temp[1])-0.5) &
                                       year_temp<(as.double(input$sample_year_temp[2])+0.5))
  
                   data_show$Mean<-as.double(data_show$Mean)
                   data_show<-data_show[!is.na(data_show$Mean),]
                   filetemp=paste0(ind_code_path,'data_analysis.csv')
                 #  write.csv(data_show,filetemp,row.names = FALSE)
                   
                   if (nrow(data_show)==0)
                   {
                     showModal(modalDialog(
                       title = "Important message",
                       "No available data",
                       easyClose = TRUE))
                     data_show<-data.frame(info='no available data')
                  #   write.csv(data_show,filetemp123,row.names = FALSE)
                   } else {
                   
                   output$liteature_data<-renderDT(
                     datatable(
                       data_show[,c(1:(ncol(data_show)-1))],options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                       editable = FALSE)  %>%   formatSignif(columns = c(14:19), digits = 3))
                   
                   indexx<-as.double(data_show$Mean)
                   
                   
                   
                   min_value<-floor(min(log10(indexx[which(indexx>0)]),na.rm=TRUE))
                   max_value<-ceiling(max(log10(indexx[which(indexx>0)]),na.rm=TRUE))
                   
              
                   
                   seqlabel<-seq(min_value,max_value,by=max(c(1,floor((max_value-min_value)/4))))
                   ticklabel<-paste0('1E',as.character(seqlabel))
                  
                   
                   if (length(seqlabel)==1)
                   {
                     seqlabel<-seq(min_value,max_value,by=0.5)
                     ticklabel<-paste0('1E',as.character(seqlabel))
                   }
                   input_unit<-input$unit
                   input_chem_filter<-input$chem_filter
                   input_chemicals<-input$chemicals
                   input_pathway<-input$pathway
                  
                   if (input$chem_filter!='all')
                   {
                   output$plot2<-renderPlot({
                 
                     
                     ggplot(data=data_show, aes(x=as.factor(year_temp),y=log10(Mean)))+ 
                       geom_boxplot(outlier.color="black",outlier.shape=16,outlier.size=2,notch=FALSE)+
                       scale_y_continuous(breaks=seqlabel,labels=ticklabel,limits=c(min_value,max_value))+
                       labs(x='Year',y=paste0('Concentration, unit: ',input_unit), title=paste0('Temporal trend for ', input_chem_filter," in ",input_pathway))+
                       theme(title=element_text(size=14,color="Blue",face='bold'),
                             axis.title.x=element_text(size=12,face="bold",color="blue"),
                             axis.title.y=element_text(size=12,face="bold",color="blue"),
                             legend.background = element_rect(fill = NA),
                             axis.text.x=element_text(size=10,angle =315, hjust = 0.5),axis.text.y=element_text(size=12)
                       )+
                       theme(panel.border = element_blank(), panel.background = element_blank(),
                             panel.grid.major = element_blank(),panel.grid.minor = element_blank(),
                             axis.line.y.left =  element_line(color='black'),
                            
                             axis.line.x.bottom =  element_line(color='black'))
                     },height = 400,width = 500)
                   } else
                   {
                     
                     output$plot2<-renderPlot({
                       
                       
                       ggplot(data=data_show, aes(x=as.factor(year_temp),y=log10(Mean)))+ 
                         geom_boxplot(outlier.color="black",outlier.shape=16,outlier.size=2,notch=FALSE)+
                         scale_y_continuous(breaks=seqlabel,labels=ticklabel,limits=c(min_value,max_value))+
                         labs(x='Year',y=paste0('Concentration, unit: ',input_unit), title=paste0('Temporal trend for ', input_chemicals," in ",input_pathway))+
                         theme(title=element_text(size=14,color="Blue",face='bold'),
                               axis.title.x=element_text(size=12,face="bold",color="blue"),
                               axis.title.y=element_text(size=12,face="bold",color="blue"),
                               legend.background = element_rect(fill = NA),
                               axis.text.x=element_text(size=10,angle =315, hjust = 0.5),axis.text.y=element_text(size=12)
                         )+
                         
                         theme(panel.border = element_blank(), panel.background = element_blank(),
                               panel.grid.major = element_blank(),panel.grid.minor = element_blank(),
                               axis.line.y.left =  element_line(color='black'),
                               axis.line.x.bottom =  element_line(color='black'))
                     },height = 400,width = 500)
                   }
                   } 
                   }
               }
               }
  )
  
  observeEvent(input$pathway,
             {
               updateActionButton(session,inputId="filter",label="Data Filt (Not done)")
               updateActionButton(session,inputId="data_shown",label="Data Refresh (Not done)")
             })
  
  observeEvent(input$chem_filter,
               {
                 updateActionButton(session,inputId="filter",label="Data Filt (Not done)")

               })
  observeEvent(input$unit,
               {
                 updateActionButton(session,inputId="filter",label="Data Filt (Not done)")

               })
  
  observeEvent(input$chemicals,
             {
               updateActionButton(session,inputId="filter",label="Data Filt (Not done)")
               updateActionButton(session,inputId="data_shown",label="Data Refresh (Not done)")
             })
               
               
  
  observeEvent(input$data_shown,
               {
                 output$title_pollutant<-renderUI({(h3("Exposure data for selected PoPs (updated to 2020-05-31)"))})
                 filetemp123=paste0(ind_code_path,'data_analysis.csv')
       file_temp_name<-paste0('./work/analysis/PoPs/',input$chemicals,'_analysis.xlsx')
                 
        if (!file.exists(file_temp_name))
                 {
                   
                   showModal(modalDialog(
                     title = "Important message",
                     "No available data",
                     easyClose = TRUE))
          data_show<-data.frame(info='no available data')
          write.csv(data_show,filetemp123,row.names = FALSE)
                 } else
                 {
                   data_all<-read.xlsx(file_temp_name)
                   
                      data_show<-subset(data_all, Pathway %in% input$pathway)
                       if (nrow(data_show)==0)
                      {
                         showModal(modalDialog(
                           title = "Important message",
                           "No available data",
                           easyClose = TRUE))
                         data_show<-data.frame(info='no available data')
                         write.csv(data_show,filetemp123,row.names = FALSE)
                        
                      } else {
                   # data_show<-data_all
                   locationid_temp<-sort(unique(data_show$Province))
                   locationid<-sort(locationid_temp[which(locationid_temp!='Not specified')])
                   unit_unique<-unique(data_show$Unit)
                   unit_no<-rep(1,length(unit_unique))
                   for (i in 1:length(unit_unique))
                   {
                     unit_no[i]=length(which(data_show$Unit==unit_unique[i]))
                   }
                   
                  
                   
                   data_unit<-data.frame(unit=unit_unique,no=unit_no)
                   data_unit<-data_unit[order(data_unit$no, decreasing = TRUE),]
                   
                   updateCheckboxGroupInput(session,"location_spat",label="Province",
                                            choices=locationid,selected=locationid,
                                            inline=TRUE)
                  
                
                     updateCheckboxGroupInput(session,"location_temp",label="Province",
                                              choices=locationid_temp,selected=locationid_temp,
                                              inline=TRUE)
                     if (length(unique(data_show$chemicals))>1)
                     {
                     chemical_list_filter<-c('all',unique(data_show$chemicals))} else 
                     
                     {
                       chemical_list_filter<-unique(data_show$chemicals)
                     }
      
                    # print(unique(data_show$chemicals))
                     
                      updateSelectInput(session,'chem_filter', label='Chemical filter for further analysis',choices=chemical_list_filter, 
                                        selected=chemical_list_filter[1])
                    
                      if (input$groups!='Dioxins and PCBs' & input$chemicals!='Polychlorinated naphthalenes')
                      {
                      
                     if (input$pathway=='air' |input$pathway=='water')
                     {
                      
                     updateSelectInput(session,'unit', label='Unit filter for further analysis',choices=data_unit$unit[1],
                                    selected=data_unit$unit[1])
                      
                       
                       } else if  (input$pathway=='dust' | input$pathway=='sediment' | input$pathway=='soil')
                       {
                         if (nrow(data_unit)>1)
                         {
                         updateSelectInput(session,'unit', 'Unit filter for further analysis',choices=data_unit$unit[1:2], 
                                           selected=data_unit$unit[1])
                         } else 
                         {
                           updateSelectInput(session,'unit', 'Unit filter for further analysis',choices=data_unit$unit[1], 
                                             selected=data_unit$unit[1])
                         }
                       } else 
                       {
                         if  (nrow(data_unit)>3)
                         {
                         updateSelectInput(session,'unit', 'Unit filter for further analysis',choices=data_unit$unit[1:4], 
                                           selected=data_unit$unit[1])
                       } else 
                       {
                         updateSelectInput(session,'unit', 'Unit filter for further analysis',choices=data_unit$unit[1:nrow(data_unit)], 
                                           selected=data_unit$unit[1]) 
                       }
                       }
                      } else 
                      {
                        updateSelectInput(session,'unit', label='Unit filter for further analysis',choices=data_unit$unit,
                                          selected=data_unit$unit[1])
                       
                      }
                   yearid1<-unique(data_show$Year)
                  yearid<-as.double(unique(str_sub(yearid1,start=1,end=4)))
                  
                updateSliderInput(session,inputId ="sample_year_temp",label="Sample Years",
                                  min=min(yearid,na.rm=TRUE), step=1,max=max(yearid,na.rm=TRUE), value=c(min(yearid,na.rm=TRUE),max(yearid,na.rm=TRUE)))
                   
                updateSliderInput(session,inputId ="sample_year_spat",label="Sample Years",
                                  min=min(yearid,na.rm=TRUE), step=1,max=max(yearid,na.rm=TRUE), value=c(min(yearid,na.rm=TRUE),max(yearid,na.rm=TRUE)))
                
                filetemp=paste0(ind_code_path,'data_analysis.csv')
                   write.csv(data_show,filetemp,row.names = FALSE)
                   updateActionButton(session,inputId="data_shown",label="Data Refresh (Done)"
                   )  
                   
                   output$liteature_data<-renderDT(
                     datatable(
                       data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                       editable = FALSE)  %>%   formatSignif(columns = c(14:19), digits = 3))
                   
                 } 
               }
                 
               }
  )
  
  observeEvent(input$spatial,
               {
                 file_temp_name<-paste0('./work/analysis/PoPs/',input$chemicals,'_analysis.xlsx')
                 if (!file.exists(file_temp_name))
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "No available data",
                     easyClose = TRUE))
                 } else
                 {
                   data_all<-read.xlsx(file_temp_name)
                   
                   if (input$chem_filter!="all")
                   {data_show1<-subset(data_all, Pathway %in% input$pathway & Unit %in% input$unit & chemicals %in% input$chem_filter)
                   } else 
                   {
                     data_show1<-subset(data_all, Pathway %in% input$pathway & Unit %in% input$unit)
                   }
                   
                   if (nrow(data_show1)==0)
                   {
                     showModal(modalDialog(
                       title = "Important message",
                       "No available data",
                       easyClose = TRUE))
                   } else
                   {
                   
                   data_show1$year_temp<-as.double(str_sub(data_show1$Year,start=1,end=4))
                   
                   data_show<-subset(data_show1, Province %in% input$location_spat & 
                                       year_temp>(as.double(input$sample_year_spat[1])-0.5) &
                                       year_temp<(as.double(input$sample_year_spat[2])+0.5))
                   
                   if (nrow(data_show)==0)
                   {
                     showModal(modalDialog(
                       title = "Important message",
                       "No available data",
                       easyClose = TRUE))
                   } else
                   {
                   data_show$Mean<-as.double(data_show$Mean)
                   data_show<-data_show[!is.na(data_show$Mean),]
                   
                   china_map<-read_excel('./work/analysis/china_map.xlsx')
                   
                   
                   data_all1<-as.data.frame(tapply(data_show$Mean,as.factor(data_show$Province),median))
                   
                   data_all2<-data.frame(namecn=rownames(data_all1),concentration=data_all1[,1])
                   
                   
                   data_all3<-data_all2[!is.na(data_all2$concentration),]
                   data_all3$logconcentration<-log10(data_all3$concentration)
                   data_all4<-data_all3[,c(1,3)]
                   
                   if (nrow(data_all3)>8)
                   {
                     index<-which(data_all3$logconcentration>quantile(data_all3$logconcentration,0.25)[[1]]-
                                    2.5*IQR(data_all3$logconcentration) & data_all3$logconcentration<quantile(data_all3$logconcentration,0.75)[[1]]+
                                    2.5*IQR(data_all3$logconcentration))
                     data_all4<-data_all3[index,c(1,3)]
                   }
                   
                   data_all2<-merge(data_all2,data_all4, by='namecn',all.x=TRUE)
                   
                   if (nrow(data_all2)==0)
                   {
                     showModal(modalDialog(
                       title = "Important message",
                       "No available data",
                       easyClose = TRUE))
                   } else 
                   {
                   
                   plot_data<-join(china_map, data_all2, type="left")
                   
                   
                   min_value<-floor(min(plot_data$logconcentration,na.rm=TRUE))
                   max_value<-ceiling(max(plot_data$logconcentration,na.rm=TRUE))
                   
                   
                   seqlabel<-seq(min_value,max_value,by=max(c(1,floor((max_value-min_value)/4))))
                   ticklabel<-paste0('1E',as.character(seqlabel))
                 
                   if (input$chem_filter!='all')
                   {
                     title_name=input$chem_filter
                   } else 
                   {
                     title_name=input$chemicals
                   }
                 input_unit<-input$unit
                 input_pathway<-input$pathway
                   output$plot3<-renderPlot({ ggplot(plot_data,aes(x=long,y=lat,group=group,fill=logconcentration))+
                     geom_polygon(colour="black",na.rm=TRUE)+
                     scale_fill_gradient(low="white",high="red",limits=c(min_value,max_value),
                                        breaks=seqlabel, labels=ticklabel, name='level')+
                     coord_map("polyconic")+labs(title=paste0('Spatial distribution for ',title_name," in ", input_pathway, ", (unit: ",input_unit,")"),
                                                 x=NULL,y=NULL)+
                     theme(
                       
                       axis.text=element_blank(),
                       axis.ticks=element_blank(),
                       axis.title=element_blank(),
                       legend.position=c(0.25,0.2),
                       plot.background = element_rect(fill = "transparent", colour = "transparent"),
                       panel.background = element_rect(fill = "transparent", colour = "transparent"),
                       panel.grid = element_blank(),
                       title=element_text(size=14,face='bold')
                       
                     )},height = 400,width = 500)
                   
               #    plot_data<-join(china_map, data_all2, type="left")
                   
                   
                   
                 #  plot_data$concentration[is.na(plot_data$concentration)]<-0
                  
               #    filetemp=paste0(ind_code_path,'data_analysis.csv')
                 #  write.csv(data_show,filetemp,row.names = FALSE)
                   output$liteature_data<-renderDT(
                     datatable(
                       data_show[,c(1:(ncol(data_show)-1))],options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                       editable = FALSE)  %>%   formatSignif(columns = c(14:19), digits = 3))
                   
                   }
                   }
                 } 
                 
               }
}
  )
  
}


#-------human health risk assessment-------------
#Ui/Server for risk assessment

 Module_hhra_Ui<-function(id){
  ns <- NS(id)
  tabItem(tabName = "hhra",
          fluidPage(
            fluidRow(
            box(title = "Step 1. Chemical Selection", width =3, solidHeader = TRUE, status = "primary",
                collapsible=TRUE, collapsed=FALSE,
                selectInput(ns('groups'),"Groups",choices=group_list,selected='OCPs'),
                selectInput(ns('chemicals'), 'Chemicals',choices=OCP_list, selected=OCP_list[1]
                ),
              #  checkboxGroupInput(ns('pathway'), label="Pathway", choices=pathway_hhra, selected=pathway_hhra,inline=TRUE),
            
                actionBttn(ns("data_shown"), label='Chemical Selection (Not done)',color = "primary",style = "gradient",size='md')  
                # 
                # br(),
                # br(),
                # 
                # downloadBttn(ns('data_shown_download'),label='Data Download',size='xs',color="success",style='pill'),
                
            ),
            box(title = "Step 2. Data filter", width =3, solidHeader = TRUE, status = "primary",
                collapsible=TRUE, collapsed=FALSE,
               
                selectInput(ns('chem_filter'), label='Chemical filter for further analysis',choices=c('all'), selected='all'),
                checkboxGroupInput(ns('pathway'), label="Pathway Selection", choices=pathway_hhra, selected=pathway_hhra,inline=TRUE),
                actionBttn(ns("filter"), label='Data Filt (Not done)',color = "primary",style = "gradient",size='md')  


            ),
            
            box(title = "Step 3. Exposure Data", width = 3, solidHeader = TRUE,status = "primary",
                collapsible=TRUE, collapsed=FALSE,
                #  selectInput(ns('data_consumption_input'), 'Consumption data',c("example"='example',"manually"="manually"), width = 120),
                #  conditionalPanel(condition=paste0("input['", ns("data_consumption_input"), "'] == 'manually' "),
                #                  numericInput(ns("num_data_consumption"), 'The number of population groups',2,step=1,width=150,min=3,max=Inf)),
                #  conditionalPanel(condition=paste0("input['", ns("data_consumption_input"), "'] == 'manually' "),
                #                  actionButton(ns("gen_data_consumption"), 'Clcik to genearte data',width=180,style="color: #FFFFFF; background-color: #4783b3; border-color: #4783b3")),
                
                sliderInput(ns("sample_year"),label="Sample Years",min=1980, max=2025, value=c(2000,2020)),
                
                checkboxGroupInput(ns("location"), label="Province",choices=c('National'), selected=c('National')),
                actionBttn(ns("exposure"), label='Exposure Data Summary (Not done)',color = "primary",style = "gradient",size='sm')
            ),
            box(title = "Step 4. Risk Estimation", width = 3, solidHeader = TRUE, status = "primary",
                collapsible=TRUE, collapsed=FALSE,
              
                numericInput(ns('rfd'), label='Reference dose (ng/kg/day)', value=100, step=1, min=1),
                br(),
                actionBttn(ns("consumption"), label='Edit Consumption Data (Not done)',color = "primary",style = "gradient",size='sm'),
                br(),
                
                br(),
                actionBttn(ns("run"), label='Risk Estimation (Not done)',color = "success",style = "gradient",size='md')
                
            )
            ),
           
            fluidRow(uiOutput(ns("title_consump_data"))),
            fluidRow(DT::dataTableOutput(ns("consump_data"))),
            fluidRow(uiOutput(ns("title_liteature_data"))),
            fluidRow(DT::dataTableOutput(ns("liteature_data")))

          )
  )
}



 Module_hhra_Server <- function(input, output, session){
#  
  
   
  observeEvent(input$groups,
               {
         updateActionButton(session,inputId="data_shown",label="Chemical Selection (Not done)")
           updateActionButton(session,inputId="filter",label="Data Filt (Not done)")
           updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Not done)")
            updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
            updateActionButton(session,inputId="exposure",label="Exposure Data Summary (Not done)")
                 if (input$groups=='OCPs')
                 {
                   updateSelectInput(session,'chemicals', 'Chemicals',choices=OCP_list,
                                     selected=OCP_list[1])

                 } else if (input$groups=='Dioxins and PCBs')
                 {
                   updateSelectInput(session,'chemicals','Chemicals',choices=PCDD_list, selected=PCDD_list[1])
                 } else if (input$groups=='BFRs')
                 {
                   updateSelectInput(session,'chemicals','Chemicals',choices=BFR_list, selected=BFR_list[1])
                 } else if (input$groups=='PFASs')
                 {
                   updateSelectInput(session,'chemicals','Chemicals',choices=PFAS_list, selected=PFAS_list[1])
                 } else if (input$groups=='Other POPs')
                 {
                   updateSelectInput(session,'chemicals','Chemicals',choices=Others_list, selected=Others_list[1])
                 }
               }
  )
   
   observeEvent(input$chemicals, {
     updateActionButton(session,inputId="data_shown",label="Chemical Selection (Not done)")
     updateActionButton(session,inputId="filter",label="Data Filt (Not done)")
     updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Not done)")
     updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
     updateActionButton(session,inputId="exposure",label="Exposure Data Summary (Not done)")
     
     file_temp_name<-paste0('./work/hhra/toxicity.xlsx')
     data_all<-read.xlsx(file_temp_name)
     data_seb<-subset(data_all, chemicals %in% input$chemicals)
     updateNumericInput(session,'rfd',label=paste0('Reference dose (ng/kg/day) for ',input$chemicals), value=as.double(data_seb$value[1]))
   })
   observeEvent(input$data_shown,
                {
                  file_temp_name<-paste0('./work/analysis/PoPs/',input$chemicals,'_analysis.xlsx')
                  
                  
                  filetemp123=paste0(ind_code_path,'data_exposure_temp.csv')
                  if (!file.exists(file_temp_name))
                  {
                    
                    showModal(modalDialog(
                      title = "Important message",
                      "No available data",
                      easyClose = TRUE))
                    
                    data_show<-data.frame(info='no available data')
                    write.csv(data_show,filetemp123,row.names = FALSE)
                  } else
                  {
                    data_all<-read.xlsx(file_temp_name)
                    data_show<-subset(data_all, Pathway %in% pathway_hhra)
                    if (nrow(data_show)==0)
                    {
                      showModal(modalDialog(
                        title = "Important message",
                        "No available data",
                        easyClose = TRUE))
                      data_show<-data.frame(info='no available data')
                      write.csv(data_show,filetemp123,row.names = FALSE)
                      
                    }   else {
                      
                      
                      data_show1<-NULL
                      
                      for (i in 1:length(pathway_hhra))
                      { data_show2<-subset(data_show, Pathway %in% pathway_hhra[i] &
                                             Unit %in% pathway_hhra_unit[i])
                      data_show1<-rbind(data_show2,data_show1)}
                      
                      if (nrow(data_show1)==0)
                      {
                        showModal(modalDialog(
                          title = "Important message",
                          "No available data",
                          easyClose = TRUE))
                        
                        data_show<-data.frame(info='no available data')
                        write.csv(data_show,filetemp123,row.names = FALSE)
                      } else 
                      {
                        
                        data_show<-data_show1
                        # print(data_show)
                        pathway_temp<-unique(data_show$Pathway)
                        updateCheckboxGroupInput(session, inputId='pathway',
                                                 label="Pathway Selection", choices=pathway_temp, selected=pathway_temp, inline = TRUE)
                        
                        
                        if (length(unique(data_show$chemicals))>1)
                        {
                          chemical_list_filter<-c('all',unique(data_show$chemicals))} else 
                            
                          {
                            chemical_list_filter<-unique(data_show$chemicals)
                          }
                        
                        # print(unique(data_show$chemicals))
                        
                        updateSelectInput(session,'chem_filter', label='Chemical filter for further analysis',choices=chemical_list_filter, 
                                          selected=chemical_list_filter[1])
                        
                        
                        
                        locationid_temp<-sort(unique(data_show$Province))
                        
                        updateCheckboxGroupInput(session,"location",label="Province",
                                                 choices=locationid_temp,selected=locationid_temp,
                                                 inline=TRUE)
                        
                        
                        yearid1<-unique(data_show$Year)
                        yearid<-as.double(unique(str_sub(yearid1,start=1,end=4)))
                        # print(yearid)
                        # print(locationid_temp)
                        updateSliderInput(session,inputId ="sample_year",label="Sample Years",
                                          min=min(yearid,na.rm=TRUE), step=1,max=max(yearid,na.rm=TRUE), value=c(min(yearid,na.rm=TRUE),max(yearid,na.rm=TRUE)))
                        
                        data_show$Mean<-as.double(data_show$Mean)
                        data_show<-data_show[!is.na(data_show$Mean),]
                        # print(data_show)
                        #write.csv(data_show,'data_test.csv')
                        
                        # print(data_all2)
                        
                        if (nrow(data_show)==0)
                        {
                          showModal(modalDialog(
                            title = "Important message",
                            "No available data",
                            easyClose = TRUE))
                          
                          data_show<-data.frame(info='no available data')
                          write.csv(data_show,filetemp123,row.names = FALSE)
                        } else
                        {
                          chemicals_name<-input$chemicals
                          updateActionButton(session,inputId="data_shown",label="Chemical Selection (Done)")
                          output$title_liteature_data<-renderUI({mainPanel(h3(paste0("Exposure data for ", chemicals_name, " (Updated to 2020-05-31)")))})
                          write.csv(data_show,filetemp123,row.names = FALSE)
                          output$liteature_data<-renderDT(
                            datatable(
                              data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                              editable = FALSE)  %>%   formatSignif(columns = c(14:19), digits = 3))
                          
                          # filetemp_write1=paste0(ind_code_path,'_hhra_exposure_write.xlsx')
                          # write.xlsx(data_all2,filetemp_write1,row.names = FALSE)
                          
                        }
                      }
                    }
                  }
                }
   )
   
   observeEvent(input$chem_filter, {
   
     updateActionButton(session,inputId="filter",label="Data Filt (Not done)")
     updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Not done)")
     updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
     updateActionButton(session,inputId="exposure",label="Exposure Data Summary (Not done)")
     
   })
   
   observeEvent(input$pathway, {
     
     updateActionButton(session,inputId="filter",label="Data Filt (Not done)")
     updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Not done)")
     updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
     updateActionButton(session,inputId="exposure",label="Exposure Data Summary (Not done)")
     
   })
   
   observeEvent(input$filter,
                {
                  file_temp_name<-paste0(ind_code_path,'data_exposure_temp_123.csv')
                  file_temp<-paste0(ind_code_path,'data_exposure_temp.csv')
                  if (!file.exists(file_temp))
                  {
                    
                    showModal(modalDialog(
                      title = "Important message",
                      "Pls select chemical prior to further analysis",
                      easyClose = TRUE))
                    
                  } else {
                    data_all<-read.csv(file_temp)
                    # print(data_all)
                    if (colnames(data_all)[1]=='info')
                    {
                      showModal(modalDialog(
                        title = "Important message",
                        "No available data",
                        easyClose = TRUE))
                      
                      data_show<-data.frame(info='no available data')
                      write.csv(data_show,file_temp_name,row.names = FALSE)
                      
                    } else {
                      data_show<-data_all
                      if (input$chem_filter!="all")
                      {data_show<-subset(data_show, Pathway %in% input$pathway & chemicals %in% input$chem_filter)
                      } else 
                      {
                        data_show<-subset(data_show,  Pathway %in% input$pathway)
                        
                      }
                      
                      
                      if (nrow(data_show)==0)
                      {
                        showModal(modalDialog(
                          title = "Important message",
                          "No available data",
                          easyClose = TRUE))
                        data_show<-data.frame(info='no available data')
                        write.csv(data_show,file_temp_name,row.names = FALSE)
                      } else
                      {
                        
                        updateActionButton(session,inputId="filter",label="Data Filt (Done)")
                        
                        
                        
                        locationid_temp<-sort(unique(data_show$Province))
                        
                        updateCheckboxGroupInput(session,"location",label="Province",
                                                 choices=locationid_temp,selected=locationid_temp,
                                                 inline=TRUE)
                        
                        
                        yearid1<-unique(data_show$Year)
                        yearid<-as.double(unique(str_sub(yearid1,start=1,end=4)))
                        # print(yearid)
                        # print(locationid_temp)
                        updateSliderInput(session,inputId ="sample_year",label="Sample Years",
                                          min=min(yearid,na.rm=TRUE), step=1,max=max(yearid,na.rm=TRUE), value=c(min(yearid,na.rm=TRUE),max(yearid,na.rm=TRUE)))
                       
                        
                        if (input$chem_filter=="all")
                        {
                          chemicals_name<-input$chemicals
                        } else 
                        {
                          chemicals_name<-input$chem_filter
                        }
                        output$title_liteature_data<-renderUI({mainPanel(h3(paste0("Exposure data for ", chemicals_name, " (Updated to 2020-05-31)")))})
                        write.csv(data_show,file_temp_name,row.names = FALSE)
                        output$liteature_data<-renderDT(
                          datatable(
                            data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                            editable = FALSE)  %>%   formatSignif(columns = c(14:19), digits = 3))
                        
                      }
                    }
                    
                    
                  }
                }
   )
   
   observeEvent(input$sample_year, {
     
     updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Not done)")
     updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
     updateActionButton(session,inputId="exposure",label="Exposure Data Summary (Not done)")
     
   })
   
   observeEvent(input$location, {
     updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Not done)")
     updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
     updateActionButton(session,inputId="exposure",label="Exposure Data Summary (Not done)")
     
   })
   
   
   observeEvent(input$exposure,
                {
                  file_temp_name<-paste0(ind_code_path,'data_exposure_temp_234.csv')
                  file_temp<-paste0(ind_code_path,'data_exposure_temp_123.csv')
                  if (!file.exists(file_temp))
                  {
                    
                    showModal(modalDialog(
                      title = "Important message",
                      "Pls finsih prior step before further analysis",
                      easyClose = TRUE))
                    
                  } else {
                  data_all<-read.csv(file_temp)
                    
                    if (colnames(data_all)[1]=='info')
                    {
                      showModal(modalDialog(
                        title = "Important message",
                        "No available data",
                        easyClose = TRUE))
                      
                      data_show<-data.frame(info='no available data')
                      write.csv(data_show,file_temp_name,row.names = FALSE)
                      
                    } else {
                      data_show<-data_all
                      
                      data_show$year_temp<-as.double(str_sub(data_show$Year,start=1,end=4))
                      
                      data_show<-subset(data_show, Province %in% input$location & 
                                          year_temp>(as.double(input$sample_year[1])-0.5) &
                                          year_temp<(as.double(input$sample_year[2])+0.5))
                      
                      
                      if (nrow(data_show)==0)
                      {
                        showModal(modalDialog(
                          title = "Important message",
                          "No available data",
                          easyClose = TRUE))
                        data_show<-data.frame(info='no available data')
                        write.csv(data_show,file_temp_name,row.names = FALSE)
                      } else
                      {
                        chemicals_name<-input$chemicals
                    data_all1<-as.data.frame(tapply(data_show$Mean,as.factor(data_show$Pathway),median))
                   data_allmin<-as.data.frame(tapply(data_show$Mean,as.factor(data_show$Pathway),min))
                  data_allmax<-as.data.frame(tapply(data_show$Mean,as.factor(data_show$Pathway),max))
                #  print(data_all1)
                   data_all2<-data.frame(chemicals=rep(chemicals_name,nrow(data_all1)),Pathway=rownames(data_all1),median_of_average=data_all1[,1],
                     min_of_average=data_allmin[,1],max_of_average=data_allmax[,1])
                   
                   data_unit_pathway<-data.frame(Pathway=pathway_hhra, Unit=pathway_hhra_unit)
                   data_all3<-merge(data_all2,data_unit_pathway,by='Pathway',all.x=TRUE)
                   data_all4<-data_all3[,c(2,1,ncol(data_all3),3:5)]
                   #  print(data_all3)
                        
                        updateActionButton(session,inputId="exposure",label="Exposure Data Summary (Done)")
                       
                        if (input$chem_filter=="all")
                        {
                          chemicals_name<-input$chemicals
                        } else 
                        {
                          chemicals_name<-input$chem_filter
                        }
                       
                        
                        output$title_liteature_data<-renderUI({mainPanel(h3(paste0("The summary on exposure data for ", chemicals_name, " (Updated to 2020-05-31)")))})
                       
                         write.csv(data_all4,file_temp_name,row.names = FALSE)
                        output$liteature_data<-renderDT(
                          datatable(
                            data_all4,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                            editable = FALSE)  %>%   formatSignif(columns = c(4:6), digits = 3))
                        
                      }
                    }
                    
                    
                  }
                }
   )
   
   observeEvent(input$rfd,
                {
                  updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
                })
   

   observeEvent(input$consumption,
                {
                  
                  file_temp<-paste0(ind_code_path,'data_exposure_temp_234.csv')
                  
                  if (!file.exists(file_temp))
                  {
                    
                    showModal(modalDialog(
                      title = "Important message",
                      "Pls summary the exposure data prior to further analysis",
                      easyClose = TRUE))
                    
                  } else 
                  {
                 data_exposure<-read.csv(file_temp)
                 if (colnames(data_exposure)[1]=='info' | nrow(data_exposure)==0 )
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "No available exposure data for further analysis",
                     easyClose = TRUE))
                   
                 } else {
                   output$title_consump_data<-renderUI({mainPanel(h3("The consumption rate for various pathways"))})
                   updateActionButton(session,inputId="consumption",label="Edit Consumption Data (Done)")
                   updateActionButton(session,inputId="run",label="Risk Estimation (Not done)")
                   file_temp_name<-paste0('./work/hhra/consumpation.xlsx')
                   data_all_consumption<-read.xlsx(file_temp_name)
                   
                   pathway_consump<-c(unique(as.character(data_exposure$Pathway)),'body weight')
                  # print(data_all_consumption)
                 #  print(pathway_consump)
                   data_show<-subset(data_all_consumption, Pathway %in% pathway_consump)
                    
                  output$consump_data<-renderDT(
                    datatable(
                      data_show[,1:3],options = list(lengthMenu=c('10','20'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                      editable = TRUE)  %>%   formatSignif(columns = c(2), digits = 3))
                  filetemp_write1=paste0(ind_code_path,'_hhra_temp_consump_write.xlsx')
                  write.xlsx(data_show,filetemp_write1,row.names = FALSE)
                 }
                  }
                })
   
   observeEvent(input$consump_data_cell_edit,  
                {
     
  
     filetemp_write1=paste0(ind_code_path,'_hhra_temp_consump_write.xlsx')
     data_show<-(read_excel(filetemp_write1))
    
     
     info = input$consump_data_cell_edit
     i = info$row
     j = info$col+1
  
     v = info$value
    
     data_show[i, j]<- as.double(v)
    
     write.xlsx(data_show,filetemp_write1,row.names = FALSE)
   }
   )

   observeEvent(input$run,{
     file_temp_consump<-paste0(ind_code_path,'_hhra_temp_consump_write.xlsx')
     file_temp_exposure<-paste0(ind_code_path,'data_exposure_temp_234.csv')
     
     if (!file.exists(file_temp_exposure))
     {
       
       showModal(modalDialog(
         title = "Important message",
         "Pls summary the exposure data prior to risk estimation",
         easyClose = TRUE))
       
     } else {
       
       if (!file.exists(file_temp_consump))
       {
         showModal(modalDialog(
           title = "Important message",
           "Pls edit the consumption data prior to risk estimation",
           easyClose = TRUE))
       } else {
         
     data_exposure<-read.csv(file_temp_exposure)
     data_consumption<-read.xlsx(file_temp_consump)
     
     if (nrow(data_exposure)==0 | nrow(data_consumption)==0 | colnames(data_exposure)[1]=='info' | colnames(data_consumption)[1]=='info')
     
     {
       showModal(modalDialog(
         title = "Important message",
         "No available data",
         easyClose = TRUE))
     } else {
     data_merge<-merge(data_exposure[,c(1, 2,3,4)],data_consumption,by='Pathway')
    
     data_bw<-subset(data_consumption, Pathway %in% 'body weight')
     
   
     data_merge$daily_intake<-as.double(data_merge$median_of_average)*as.double(data_merge$Consumption_Rate)/
       as.double(data_bw$Consumption_Rate)
       data_merge$risk<-data_merge$daily_intake/as.double(input$rfd)
      
       data_show<-data_merge[,c(1,7,8)]
     # # 
       data_temp<-data.frame(Pathway='All',daily_intake=sum(data_show$daily_intake),risk=
                   sum(data_show$risk))
       
     # 
     data_show<-rbind(data_show,data_temp)
     
     data_merge$median_of_average=paste0(as.character(signif(data_merge$median_of_average,2)),' ',data_merge[,3])
     data_merge$Consumption_Rate=paste0(as.character(signif(data_merge$Consumption_Rate,2)),' ',data_merge[,6])
     
     data_show1<-merge(data_show,data_merge[,c(1,2,4,5)],by='Pathway',all.x=TRUE)
     
     data_show2<-data_show1[,c(4,1,5,6,2,3)]
     
     colnames(data_show2)[1:6]<-c('Chemicals',"Pathway",'Concentration','Consumption_Rate','Daily_Intake(ng/kg/day)',"Risk")
     
    data_show2$Chemicals[nrow(data_show2)]<-data_show2$Chemicals[nrow(data_show2)-1]
    
    if (input$chem_filter=="all")
    {
      input_chem<-input$chemicals
    } else 
    {
      input_chem<-input$chem_filter
    }
    output$title_consump_data<-renderUI({mainPanel(h3(paste0("Risk estimation for ", input_chem)))})
    updateActionButton(session,inputId="run",label="Risk Estimation (Done)")
      output$consump_data<-renderDT(
        datatable(
         data_show2,options = list(lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
          editable = FALSE)  %>%   formatSignif(columns = c(5:6), digits = 2))
     }
       }
     }
   }
   )

}


#-------recent update----
Module_update_Ui <- function(id){
  ns <- NS(id)
  tabItem(tabName = "update", 
          fluidPage(
            fluidRow(
              box(title = "Step 1. Chemical Selection", width =6, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  selectInput(ns('groups'),"Groups",choices=group_list,selected='OCPs'),
                  checkboxGroupInput(ns('chemicals'), 'Chemicals',choices=OCP_list, selected=OCP_list,
                                     inline=TRUE)
                  
              ),
              
              
           
            
              box(title = "Step 2. Recent Literature", width = 3, solidHeader = TRUE, status = "primary",
                  collapsible=TRUE, collapsed=FALSE,
                  actionBttn(ns("data_shown"), label='GO!',color = "primary",style = "gradient",size='lg'),
                  br(),
                  br(),
                  downloadBttn(ns('data_shown_download'),label='Data Download',size='sm',color="success",style='pill')
              )
              
              
            ),
            
            fluidRow(uiOutput(ns("title_pollutant"))),
            fluidRow(DT::dataTableOutput(ns("liteature_data")))
           
          )
  )
}

Module_update_Server <- function(input, output, session){

  observeEvent(input$groups,
               {
                 
                 if (input$groups=='OCPs')
                 {
                   updateCheckboxGroupInput(session,'chemicals', 'Chemicals',choices=OCP_list, 
                                            selected=OCP_list, inline=TRUE)
                   
                 } else if (input$groups=='Dioxins and PCBs')
                 {
                   updateCheckboxGroupInput(session,'chemicals','Chemicals',choices=PCDD_list, selected=PCDD_list,
                                            inline=TRUE)
                 } else if (input$groups=='BFRs')
                 {
                   updateCheckboxGroupInput(session,'chemicals','Chemicals',choices=BFR_list, selected=BFR_list,
                                            inline=TRUE)
                 } else if (input$groups=='PFASs')
                 {
                   updateCheckboxGroupInput(session,'chemicals','Chemicals',choices=PFAS_list, selected=PFAS_list,
                                            inline=TRUE)
                 } else if (input$groups=='Other POPs')
                 {
                   updateCheckboxGroupInput(session,'chemicals','Chemicals',choices=Others_list, selected=Others_list,
                                            inline=TRUE)
                 }
               }
  )
  
  output$data_shown_download<-downloadHandler(filename = function(){
    paste("recent",gsub(":","-",Sys.time()), ".csv", sep="")
  },
  content=function(con)
  {file.copy(paste0(ind_code_path,'recent.csv'),con)
  })
  
  observeEvent(input$data_shown,
               {
                 
                 
                 data_all<-read.xlsx('./work/recent/all_recent.xlsx')
                 data_show<-subset(data_all, sub_groups %in% input$chemicals)
                
                 
                 if (nrow(data_show)>0)
                 { 
                   output$title_pollutant<-renderUI({mainPanel(h3("Summary on recent liteature (Updated to 2020-08-12)"))})
                   filetemp=paste0(ind_code_path,'recent.csv')
                 
                 colnames(data_show)[2]<-'chemical'
                 write.csv(data_show,filetemp,row.names = FALSE)
                 output$liteature_data<-renderDT(
                   datatable(
                     data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE,scrollX=TRUE),rownames=FALSE,
                     editable = FALSE))
                 
               
                 } else
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "No available data",
                     easyClose = TRUE))
                 }
               }
               
  )
}
#-----main framework-------------
ui <- dashboardPage(
  dashboardHeader(),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Introduction", tabName="introduction"),
      menuItem("Liteature summary", tabName = "lit"),
      menuItem("Exposure database", tabName = "database"),
      menuItem("Data analysis", tabName = "analysis"),
      menuItem("Human health risk assessment", tabName = "hhra"),
      menuItem("Recent literature", tabName = "update")
    )
  ),
  dashboardBody(
    tabItems(
      Module_introduction_Ui("introduction"),
      Module_lit_Ui("lit"),
      Module_database_Ui("database"),
      Module_analysis_Ui("analysis"),
      Module_hhra_Ui("hhra"),
      Module_update_Ui("update")
    )))

server <- function(input,output,server){
  callModule(Module_introduction_Server,"introduction")
  callModule(Module_lit_Server,"lit")
  callModule(Module_database_Server,"database")
  callModule(Module_analysis_Server,"analysis")
  callModule(Module_hhra_Server,"hhra")
  callModule(Module_update_Server,"update")
}

shinyApp(ui,server)