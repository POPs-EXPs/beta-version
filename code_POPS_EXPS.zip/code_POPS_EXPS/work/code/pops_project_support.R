data_consumption_gen<-function(num,pathways)
{ 
  
  pathways<-c('体重',pathways)
  distribution_default<-c(1,rep(0,length(pathways)-1))
  parameter_2_default<-c(0,rep(1,length(pathways)-1))
  
  unit_default<-c('kg',rep("kg/day",length(pathways)-1))

  data_out<-data.frame(age=matrix(t(matrix(rep(1:num,length(pathways)),nrow=num)),ncol=1),group=rep((pathways),num),
                       distribution=rep(distribution_default,num),
                       parameter_1=rep(1,num*length(pathways)),
                       
                       parameter_2=rep(parameter_2_default,num), 
                       bioavailability=rep(1,num*length(pathways)),
                       unit=rep(unit_default,num))
return((data_out))
}

data_pollutant_gen<-function(num)
{ 
  path<-NULL
for (i in 1:num)
{
  path<-rbind(path,paste0('pathway',as.character(i)))
}
  
  data_out<-data.frame(pathway=path,distribution=rep(0,num),
                      
                       parameter_1=rep(1,num),
                       
                       parameter_2=rep(1,num), unit_conversion=rep(1,num),unit=rep('mg/kg',num))
  return((data_out))
}

exposure_basic_check<-function(data_show,data_show1)

{
  check_index1<-1
  distribution_index<-which(data_show$distribution==0)
  distribution_index1<-which(data_show1$distribution==0)
  
  msg_send<-NULL
  distribution_default<-c(0,1,2)
  
 if (!all(unique(data_show$distribution)%in%distribution_default))
  {
   ( msg_send<-c('污染物数据分类类型应该是数字0、1、2且非空；如果采用非随机方法计算，可设定分布类型为对数正态分布
                (即分类类型为0) ，并且几何标准差(parameter_2)为1。'))
    check_index1<-0
  } else if (!all(unique(data_show1$distribution)%in%distribution_default))
  {
    ( msg_send<-c('暴露参数分类类型应该是数字0、1、2且非空；如果采用非随机方法计算，可设定分布类型为对数正态分布
                (即分类类型为0) ，并且几何标准差(parameter_2)为1。'))
    check_index1<-0
  } else if (is.na(sum(as.double(data_show$parameter_1),na.rm=FALSE)) | is.na(sum(as.double(data_show$parameter_2),na.rm=FALSE)))
  {
    ( msg_send<-c('污染物质浓度的分布参数输入应为数字且非空'))
    check_index1<-0
  } else if (min(as.double(data_show$parameter_1))<0 | min(as.double(data_show$parameter_2))<0)
  {
    ( msg_send<-c('污染物质浓度的分布参数应为非负数'))
    check_index1<-0
  } else if (is.na(sum(as.double(data_show1$parameter_1),na.rm=FALSE)) | is.na(sum(as.double(data_show1$parameter_2),
     na.rm=FALSE)) )
  {
    ( msg_send<-c('暴露参数的分布参数输入应为数字且非空'))
    check_index1<-0
  } else if (min(as.double(data_show1$parameter_1))<0 | min(as.double(data_show1$parameter_2))<0)
  {
    ( msg_send<-c('暴露参数的分布参数应为非负数'))
    check_index1<-0
  } else if (is.na(sum(as.double(data_show1$bioavailability))))
  {
    ( msg_send<-c('暴露参数中的生物有效性输入应为数字且非空'))
    check_index1<-0
  } else if (min(as.double(data_show1$bioavailability))<0 | max(as.double(data_show1$bioavailability))>1 )
  {
    ( msg_send<-c('暴露参数中的生物有效性范围应为0-1'))
    check_index1<-0
  } else if ((any(is.na(data_show))) |  (any(is.na(data_show))) )
   { check_index1<-0
    msg_send<-'污染物质以及暴露参数输入中不能有空值'
  } else if (any(duplicated(data_show$pathway)))
  {
    check_index1<-0
    msg_send<-'污染物质的暴露途径有重复值'
  } else if (is.element('合计',data_show$pathway)) 
  {
    check_index1<-0
    msg_send<-'污染物质的暴露途径不能命名为合计'
  }  else  if (length(distribution_index)>0 & min(as.double(data_show$parameter_2[distribution_index]))<1)
  {
    check_index1<-0
    msg_send<-paste0("污染物质中对数正态分布的几何标准差需要大于1")
  } else if (length(distribution_index1)>0 & min(as.double(data_show1$parameter_2[distribution_index1]))<1)
  {
    check_index1<-0
    msg_send<-paste0("暴露参数中对数正态分布的几何标准差需要大于1")
  } else if (length(data_show1$age)>0)
  {
  age_group<-unique(data_show1$age)

  for (age_loop in age_group)
  {
   index<-which(data_show1$age==age_loop)
   path<-data_show1$group[index]
   if ((any(duplicated(path))) & check_index1==1) 
   {
     check_index1<-0
     msg_send<-paste0("暴露参数中age为",age_loop,'组的group参数有重复值')
     
   } else if (!is.element('体重',path) & check_index1==1) 
   {
     check_index1<-0
     msg_send<-paste0("暴露参数中age为",age_loop,'组的group参数没有体重')
    
   }   else if (!setequal(path,c(data_show$pathway,'体重')) & check_index1==1) 
   {
     check_index1<-0
     msg_send<-paste0("暴露参数中age为",age_loop,'组的暴露途径和污染物的暴露途径设置不一致')
   
     }
  }
  } 
  
  
  if (!is.null(msg_send))
  {showModal(modalDialog(
    title = "Important message",
    msg_send,
    easyClose = TRUE
  ))} else
  {
    showModal(modalDialog(
      title = "Important message",
      '数据检查成功，请执行下一步操作',
      easyClose = TRUE
    ))
  }
  return(check_index1)
}

exposure_basic_calc<-function(data_show,data_show1,filename_xls)
{
  age_group<-unique(data_show1$age)
 data_result_all<-NULL
 nn<-50000
 total_all_uptake<-NULL
  for (age_loop in age_group)
  {
    data_temp<-subset(data_show1,age==age_loop & group!='体重')
    data_temp1<-subset(data_show1,age==age_loop & group=='体重')
    body_weight_temp<-exposure_basic_random(data_temp1$parameter_1,data_temp1$parameter_2,data_temp1$distribution)
    uptake_specific_value<-matrix(0,length(data_temp$group),nn)
    data_result_age<-NULL
     for (path_loop in 1:length(data_show$pathway))
    {
       index_pathway<-which(data_temp$group==data_show$pathway[path_loop])
      consum_temp<-exposure_basic_random(data_temp$parameter_1[index_pathway],data_temp$parameter_2[index_pathway],data_temp$distribution[index_pathway])
      
    pollutant_temp<-exposure_basic_random(data_show$parameter_1[path_loop],
      data_show$parameter_2[path_loop], data_show$distribution[path_loop])
    uptake_specific_value[path_loop,]<-consum_temp*pollutant_temp*data_show$unit_conversion[path_loop]*
      data_temp$bioavailability[index_pathway]/body_weight_temp
    
    
    data_result<-data.frame(age=age_loop,path=data_show$pathway[path_loop],mean=mean(uptake_specific_value[path_loop,],na.rm=FALSE),
                          std=sd(uptake_specific_value[path_loop,],na.rm=TRUE),
                          median=median(uptake_specific_value[path_loop,],na.rm=TRUE),
                          gm=exp(mean(log(uptake_specific_value[path_loop,]),na.rm=TRUE)),
                          gsd=exp(sd(log(uptake_specific_value[path_loop,]),na.rm=TRUE)),
                          ratio=0.1,
                          per_05=quantile(uptake_specific_value[path_loop,],probs=0.05,na.rm=TRUE)[[1]],
                          per_25=quantile(uptake_specific_value[path_loop,],probs=0.25,na.rm=TRUE)[[1]],
                          per_75=quantile(uptake_specific_value[path_loop,],probs=0.75,na.rm=TRUE)[[1]],
                          per_95=quantile(uptake_specific_value[path_loop,],probs=0.95,na.rm=TRUE)[[1]]
                            )
    data_result_age<-rbind(data_result_age,data_result)
     }
    total_all_uptake<-rbind(total_all_uptake,uptake_specific_value)
    total_uptake<-t(matrix(rep(colSums(uptake_specific_value,
                                       na.rm=TRUE),length(data_temp$group)),ncol=length(data_temp$group)))
    data_result_age$ratio<- rowMeans(uptake_specific_value/total_uptake,
                     na.rm=TRUE)
    data_result_age_combine<-NULL
    data_result_age_combine<-data.frame(age=age_loop,path='合计',
                                mean=mean(total_uptake),std= sd(total_uptake),
                                median=median(total_uptake),     gm=exp(mean(log(total_uptake))),
                                gsd=exp(sd(log(total_uptake))),
                                ratio=1,per_05=quantile(total_uptake,probs=0.05)[[1]],
                                per_25=quantile(total_uptake,probs=0.25)[[1]],
                                per_75=quantile(total_uptake,probs=0.75)[[1]],
                                per_95=quantile(total_uptake,probs=0.95)[[1]])
    data_result_age<-rbind(data_result_age,data_result_age_combine)
    data_result_all<-rbind(data_result_all,data_result_age) 
    
  }
 
 #下面是为了做出所有age合并在一起的数据
 if (length(age_group)>1)
 {
 data_for_calc_all_age<-matrix(0,nrow=length(data_show$pathway),nn)
 
 for (i in 1:length(data_show$pathway))
 {
   data_for_calc_all_age[i,]<-colMeans(total_all_uptake[seq(i,nrow(total_all_uptake),length(data_show$pathway)),])
 }
 
 data_result_age_allF1<-NULL
 for (i in 1:length(data_show$pathway))
 {
   data_result_ageall<-data.frame(age='全年龄',
                                  path=data_show$pathway[i],mean=mean(data_for_calc_all_age[i,]),std=sd(data_for_calc_all_age[i,]),
                                  median=median(data_for_calc_all_age[i,]),gm=exp(mean(log(data_for_calc_all_age[i,]))),
                                  gsd=exp(sd(log(data_for_calc_all_age[i,]))),ratio=0.1,
                                  per_05=quantile(data_for_calc_all_age[i,],probs=0.05)[[1]],
                                  per_25=quantile(data_for_calc_all_age[i,],probs=0.25)[[1]],
                                  per_75=quantile(data_for_calc_all_age[i,],probs=0.75)[[1]],
                                  per_95=quantile(data_for_calc_all_age[i,],probs=0.95)[[1]])
                                  
   data_result_age_allF1<-rbind(data_result_age_allF1, data_result_ageall)                                
 }
 

 total_uptake_final_version<-t(matrix(rep(colSums( data_for_calc_all_age,
                                    na.rm=TRUE),length(data_temp$group)),ncol=length(data_temp$group)))
 data_result_age_allF1$ratio<- rowMeans(data_for_calc_all_age/ total_uptake_final_version,
                                  na.rm=TRUE)

 data_result_age_combine_F1<-data.frame(age='全年龄',path='合计',
                                     mean=mean( total_uptake_final_version),std= sd( total_uptake_final_version),
                                     median=median( total_uptake_final_version),     gm=exp(mean(log( total_uptake_final_version))),
                                     gsd=exp(sd(log( total_uptake_final_version))),
                                     ratio=1,per_05=quantile( total_uptake_final_version,probs=0.05)[[1]],
                                     per_25=quantile( total_uptake_final_version,probs=0.25)[[1]],
                                     per_75=quantile( total_uptake_final_version,probs=0.75)[[1]],
                                     per_95=quantile( total_uptake_final_version,probs=0.95)[[1]])
 data_result_age_allF1<-rbind(data_result_age_allF1,data_result_age_combine_F1)
 
 data_result_all<-rbind( data_result_all,data_result_age_allF1)
 } 
 
 colnames(data_result_all)<-c('age','暴露途径','平均值','标准差','中间值',
                              "几何均值","几何标准","贡献率","5%分位数","25%分位数",
                              "75%分位数","95%分位数")
write.xlsx(data_result_all,filename_xls)   
 return(data_result_all)
}

exposure_basic_random<-function(parameter_1,parameter_2,distribution_type)
{
  n=50000
 
  if (distribution_type==0)
  {
    exposure_basic_value<-rlnorm(n,log(parameter_1),log(parameter_2))
  } else if (distribution_type==1)
  {
    exposure_basic_value<-rtruncnorm(n, a=0, b=Inf, mean =parameter_1, sd =parameter_2)
  } else if (distribution_type==2)
  {
    exposure_basic_value<-runif(n, min=parameter_1, max =parameter_2)
  }
  return(exposure_basic_value)
}

data_gen_bmd<-function(type,num)
{
  if (type=='binomial')
  {
    data_show<-data.frame(dose=c(1:num),n=rep(10,num),affected=c(1:num))
    
  } else if (type=="continuous")
    
  {
    data_show<-data.frame(dose=c(1:num),factor_levels=c(1:num))
    
  }
  return(data_show)
}

toxicity_bmd_check<-function(type,data_show)
  
{
  check_index1<-1
  msg_send<-NULL
  
  if (type=="binomial")
  {
    if (is.na(sum(as.double(data_show$dose),na.rm=FALSE)) | is.na(sum(as.double(data_show$n),na.rm=FALSE)) |is.na(sum(as.double(data_show$affected),na.rm=FALSE)) )
    {
      msg_send<-c('所有输入应为数字且非空')
      check_index1<-0
    } else if (min(as.double(data_show$dose))<0 | min(as.double(data_show$n))<0 |  min(as.double(data_show$affected))<0)
      
    {
      msg_send<-c('所有输入应为非负数')
      check_index1<-0
    }
  } else if (type=="continuous")
  {
    if (is.na(sum(as.double(data_show$dose),na.rm=FALSE)) | is.na(sum(as.double(data_show$factor_levels),na.rm=FALSE)) )
    {
      msg_send<-c('所有输入应为数字且非空')
      check_index1<-0
    } else if (min(as.double(data_show$dose))<0 | min(as.double(data_show$factor_levels))<0)
      
    {
      msg_send<-c('所有输入应为非负数')
      check_index1<-0
    } 
  }
  
  
  
  if (!is.null(msg_send))
  {showModal(modalDialog(
    title = "Important message",
    msg_send,
    easyClose = TRUE
  ))} else
  {
    showModal(modalDialog(
      title = "Important message",
      '数据检查成功，请执行下一步操作',
      easyClose = TRUE
    ))
  }
  return(check_index1)
}



toxicity_bmd_model_selection<-function(data_show,data_type,model_type)
{
  if (data_type=="binomial")
  {
    if (model_type=="LL.2")
    {
      bmdmodel_define<-drm(affected/n~dose,weights=n,data=data_show,fct=LL.2(), type="binomial")
    } else if (model_type=="LL.3")
    {
      bmdmodel_define<-drm(affected/n~dose,weights=n,data=data_show,fct=LL.3(), type="binomial")
    } else if (model_type=="W1.2")
    {
      bmdmodel_define<-drm(affected/n~dose,weights=n,data=data_show,fct=W1.2(), type="binomial")
    } else if (model_type=="W2.2")
    {
      bmdmodel_define<-drm(affected/n~dose,weights=n,data=data_show,fct=W2.2(), type="binomial")
    } else if (model_type=="LL2.2")
    {
      bmdmodel_define<-drm(affected/n~dose,weights=n,data=data_show,fct=LL2.2(), type="binomial")
    } else if (model_type=="LL2.3")
    {
      bmdmodel_define<-drm(affected/n~dose,weights=n,data=data_show,fct=LL2.3(), type="binomial")
    } else if (model_type=="MM.2")
    {
      bmdmodel_define<-drm(affected/n~dose,weights=n,data=data_show,fct=MM.2(), type="binomial")
    } else if (model_type=="MM.3")
    {
      bmdmodel_define<-drm(affected/n~dose,weights=n,data=data_show,fct=MM.3(), type="binomial")
    } 
  } else if (data_type=="continuous")
  {
    if (model_type=="LL.2")
    {
      bmdmodel_define<-drm(factor_levels~dose,data=data_show,fct=LL.2(), type="continuous")
    } else if (model_type=="LL.3")
    {
      bmdmodel_define<-drm(factor_levels~dose,data=data_show,fct=LL.3(), type="continuous")
    } else if (model_type=="W1.2")
    {
      bmdmodel_define<-drm(factor_levels~dose,data=data_show,fct=W1.2(), type="continuous")
    } else if (model_type=="W2.2")
    {
      bmdmodel_define<-drm(factor_levels~dose,data=data_show,fct=W2.2(), type="continuous")
    } else if (model_type=="LL2.2")
    {
      bmdmodel_define<-drm(factor_levels~dose,data=data_show,fct=LL2.2(), type="continuous")
    } else if (model_type=="LL2.3")
    {
      bmdmodel_define<-drm(factor_levels~dose,data=data_show,fct=LL2.3(), type="continuous")
    } else if (model_type=="MM.2")
    {
      bmdmodel_define<-drm(factor_levels~dose,data=data_show,fct=MM.2(), type="continuous")
    } else if (model_type=="MM.3")
    {
      bmdmodel_define<-drm(factor_levels~dose,data=data_show,fct=MM.3(), type="continuous")
    } 
  }
return(bmdmodel_define)
}

toxicity_ssd_check<-function(data_show)
  
{
  check_index1<-1
  msg_send<-NULL
  

  {
    if (is.na(sum(as.double(data_show$Conc),na.rm=FALSE)))
    {
      msg_send<-c('浓度输入应为数字且非空')
      check_index1<-0
    } else if (min(as.double(data_show$Conc))<0)
      
    {
      msg_send<-c('浓度输入应为非负数')
      check_index1<-0
    } 
    
    # else if ((any(duplicated(data_show$species))))
    # {
    #   msg_send<-c('species输入应没有重复')
    #   check_index1<-0
    # }
  } 
  
  
  
  
  if (!is.null(msg_send))
  {showModal(modalDialog(
    title = "Important message",
    msg_send,
    easyClose = TRUE
  ))} else
  {
    showModal(modalDialog(
      title = "Important message",
      '数据检查成功，请执行下一步操作',
      easyClose = TRUE
    ))
  }
  return(check_index1)
}

tool_meta_check<-function(data_show,ss1,ss2)
  
{
  check_index1<-1
  msg_send<-NULL
  
  
  {
    if (is.na(sum(as.double(unlist(data_show[,ss1])),na.rm=FALSE)) | is.na(sum(as.double(unlist(data_show[,ss2])),na.rm=FALSE)))
    {
      msg_send<-c('效应及其标准差输入应该为数字')
      check_index1<-0
    } else if (min(as.double(unlist(data_show[,ss2])))<=0)
      
    {
      msg_send<-c('效应标准差应为正数')
      check_index1<-0
    } 
    
  
  } 
  
  
  
  
  if (!is.null(msg_send))
  {showModal(modalDialog(
    title = "Important message",
    msg_send,
    easyClose = TRUE
  ))} else
  {
    showModal(modalDialog(
      title = "Important message",
      '数据检查成功，请执行下一步操作',
      easyClose = TRUE
    ))
  }
  return(check_index1)
}
